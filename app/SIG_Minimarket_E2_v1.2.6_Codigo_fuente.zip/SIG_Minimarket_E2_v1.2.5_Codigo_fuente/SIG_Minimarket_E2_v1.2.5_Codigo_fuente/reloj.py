"""Hora operativa chilena y conversión de timestamps SQLite (UTC)."""
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

CHILE = ZoneInfo('America/Santiago')

def ahora_chile():
    return datetime.now(CHILE)

def hoy_chile():
    return ahora_chile().date().isoformat()

def ahora_utc_sql():
    return datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S')

def fecha_chile_sql(timestamp):
    if not timestamp:
        return None
    try:
        instante = datetime.fromisoformat(str(timestamp).replace('Z', '+00:00'))
        if instante.tzinfo is None:
            instante = instante.replace(tzinfo=timezone.utc)
        return instante.astimezone(CHILE).date().isoformat()
    except (TypeError, ValueError, OverflowError):
        return None

def fecha_hora_chile(timestamp):
    if not timestamp:
        return '—'
    try:
        instante = datetime.fromisoformat(str(timestamp).replace('Z', '+00:00'))
        if instante.tzinfo is None:
            instante=instante.replace(tzinfo=timezone.utc)
        return instante.astimezone(CHILE).strftime('%d-%m-%Y %H:%M:%S')
    except (ValueError, TypeError):
        return str(timestamp)

def folio(fecha, secuencia):
    return 'BOL-' + datetime.strptime(fecha, '%Y-%m-%d').strftime('%d%m%Y') + f'{secuencia:04d}'
