"""Operaciones del SIG; stock y CPP solo se modifican mediante triggers SQLite."""
from datetime import date
from decimal import Decimal, InvalidOperation
import sqlite3
from uuid import uuid4
from reloj import ahora_chile, ahora_utc_sql, hoy_chile, folio
from db import escritura

class ErrorOperacion(ValueError):
    pass

def texto(d, clave, limite=240, obligatorio=False):
    val = (d.get(clave) or '').strip()
    if len(val)>limite or (obligatorio and not val):
        raise ErrorOperacion(f'El campo {clave.replace("_"," ")} no tiene un valor válido.')
    return val

def entero(valor, etiqueta, minimo=0, maximo=1000000000):
    try:
        s=str(valor).strip()
        if not s or any(ch not in '0123456789' for ch in s):
            raise ValueError
        n=int(s)
    except (TypeError, ValueError):
        raise ErrorOperacion(f'{etiqueta}: ingresa un número entero válido.')
    if n<minimo or n>maximo:
        raise ErrorOperacion(f'{etiqueta}: valor fuera del rango permitido.')
    return n

def delta_entero(valor):
    try:
        s=str(valor).strip()
        if not s or any(ch not in '-0123456789' for ch in s) or s.count('-')>1 or ('-' in s and not s.startswith('-')):
            raise ValueError
        n=int(s)
    except (ValueError, TypeError):
        raise ErrorOperacion('La variación debe ser un número entero con signo.')
    if n==0 or abs(n)>1000000000:
        raise ErrorOperacion('La variación debe ser distinta de cero y estar dentro de un rango válido.')
    return n

def decimal_positivo(valor, etiqueta, vacio_permitido=False):
    if vacio_permitido and (valor is None or str(valor).strip()==''):
        return None
    try:
        n=Decimal(str(valor).strip().replace(',','.'))
    except (InvalidOperation, ValueError):
        raise ErrorOperacion(f'{etiqueta}: ingresa un valor numérico válido.')
    if not n.is_finite() or n<0 or n>Decimal('100000000000'):
        raise ErrorOperacion(f'{etiqueta}: valor fuera del rango permitido.')
    return float(n)

def id_valido(con, tabla, campo, valor, activo=False):
    identificador=entero(valor, tabla, 1)
    # Los nombres están definidos internamente, nunca vienen del formulario.
    condicion = ' AND activo=1' if activo else ''
    row=con.execute(f'SELECT * FROM {tabla} WHERE {campo}=?{condicion}',(identificador,)).fetchone()
    if row is None:
        raise ErrorOperacion(f'No se encontró {tabla} válido.')
    return row

def guardar_producto(datos, producto_id=None):
    barras=texto(datos,'codigo_barras',80) or None
    modo=datos.get('modo_codigo')
    if producto_id is None:
        if modo == 'sin':
            if barras:
                raise ErrorOperacion('Un producto sin código de barras no puede llevar uno.')
            barras=None
        elif modo == 'con':
            if not barras:
                raise ErrorOperacion('Escanea o escribe el código de barras comercial.')
        elif modo is not None:
            raise ErrorOperacion('Selecciona con o sin código de barras.')
    else:
        if modo == 'sin': barras=None
        elif modo == 'con' and not barras:
            raise ErrorOperacion('Falta el código de barras del producto.')
    nombre=texto(datos,'nombre',180,True)
    precio=entero(datos.get('precio_venta'),'Precio de venta',0)
    minimo=entero(datos.get('stock_minimo'),'Stock mínimo',0)
    activo=1 if str(datos.get('activo','1'))=='1' else 0
    with escritura() as con:
        prov = id_valido(con,'proveedor','id_proveedor',datos.get('id_proveedor_principal'))['id_proveedor'] if datos.get('id_proveedor_principal') else None
        if barras:
            existe=con.execute('SELECT id_producto FROM producto WHERE codigo_barras=?',(barras,)).fetchone()
            if existe and (producto_id is None or existe['id_producto']!=int(producto_id)):
                raise ErrorOperacion('Ese código de barras ya pertenece a otro producto.')
        if producto_id is None:
            for _ in range(8):
                codigo='INT-'+uuid4().hex[:12].upper()
                if con.execute('SELECT 1 FROM producto WHERE codigo_interno=?',(codigo,)).fetchone() is None:
                    break
            else:
                raise ErrorOperacion('No fue posible asignar un código interno único.')
            cur=con.execute('''INSERT INTO producto(codigo_interno,codigo_barras,nombre,precio_venta,stock_minimo,id_proveedor_principal,activo)
                           VALUES(?,?,?,?,?,?,?)''',(codigo,barras,nombre,precio,minimo,prov,activo))
            return cur.lastrowid
        anterior=id_valido(con,'producto','id_producto',producto_id)
        con.execute('''UPDATE producto SET codigo_barras=?,nombre=?,precio_venta=?,stock_minimo=?,id_proveedor_principal=?,activo=? WHERE id_producto=?''',
                    (barras,nombre,precio,minimo,prov,activo,anterior['id_producto']))
        return producto_id

def guardar_proveedor(datos, proveedor_id=None):
    nombre=texto(datos,'nombre',180,True)
    plazo=entero(datos['plazo_entrega_dias'],'Plazo de entrega',0,365) if datos.get('plazo_entrega_dias') else None
    activo=1 if str(datos.get('activo','1'))=='1' else 0
    with escritura() as con:
        if proveedor_id is None:
            cur=con.execute('INSERT INTO proveedor(nombre,plazo_entrega_dias,activo) VALUES(?,?,?)',(nombre,plazo,activo))
            return cur.lastrowid
        id_valido(con,'proveedor','id_proveedor',proveedor_id)
        con.execute('UPDATE proveedor SET nombre=?,plazo_entrega_dias=?,activo=? WHERE id_proveedor=?',
                    (nombre,plazo,activo,proveedor_id))
        return proveedor_id

def guardar_pedido(datos):
    productos=datos.getlist('id_producto')
    cantidades=datos.getlist('cantidad')
    costos=datos.getlist('costo_estimado')
    if not productos or not(len(productos)==len(cantidades)==len(costos)) or len(productos)>60:
        raise ErrorOperacion('Agrega entre 1 y 60 productos al pedido.')
    fecha=texto(datos,'fecha_entrega_estimada',10,True)
    try:
        fecha_iso=date.fromisoformat(fecha)
        if fecha_iso.isoformat()!=fecha: raise ValueError
    except ValueError:
        raise ErrorOperacion('La fecha esperada no es válida.')
    items=[]
    seen=set()
    for p,q,c in zip(productos,cantidades,costos):
        ident=entero(p,'Producto',1)
        if ident in seen: raise ErrorOperacion('Un producto aparece dos veces en el pedido.')
        seen.add(ident)
        items.append((ident,entero(q,'Cantidad solicitada',1),decimal_positivo(c,'Costo estimado',True)))
    with escritura() as con:
        prov=id_valido(con,'proveedor','id_proveedor',datos.get('id_proveedor'),True)
        hoy=hoy_chile()
        if fecha<hoy: raise ErrorOperacion('La entrega esperada no puede ser anterior a la fecha del pedido.')
        for p,_,_ in items:
            id_valido(con,'producto','id_producto',p,True)
        cur=con.execute('INSERT INTO pedido(id_proveedor,fecha_pedido,fecha_entrega_estimada,observacion) VALUES(?,?,?,?)',
                        (prov['id_proveedor'],ahora_chile().strftime('%Y-%m-%d %H:%M:%S'),fecha,texto(datos,'observacion',500) or None))
        pedido_id=cur.lastrowid
        for p,q,c in items:
            con.execute('INSERT INTO detalle_pedido(id_pedido,id_producto,cantidad_solicitada,costo_unitario_estimado) VALUES(?,?,?,?)',
                        (pedido_id,p,q,c))
        return pedido_id

def cancelar_pedido(id_pedido):
    with escritura() as con:
        ped=id_valido(con,'pedido','id_pedido',id_pedido)
        if ped['estado_gestion']=='CANCELADO': raise ErrorOperacion('El pedido ya está cancelado.')
        con.execute("UPDATE pedido SET estado_gestion='CANCELADO' WHERE id_pedido=?", (id_pedido,))

def guardar_entrada(datos):
    cantidad=entero(datos.get('cantidad'),'Cantidad recibida',1)
    costo=decimal_positivo(datos.get('costo_unitario'),'Costo unitario')
    linea_id=datos.get('id_detalle_pedido') or ''
    tipo=texto(datos,'tipo_entrada',20,True)
    if tipo not in ('CARGA_INICIAL','RECEPCION'):
        raise ErrorOperacion('Tipo de entrada no válido.')
    with escritura() as con:
        if linea_id:
            if tipo!='RECEPCION': raise ErrorOperacion('La recepción de un pedido no puede ser carga inicial.')
            linea=con.execute('''SELECT dp.*, ped.id_proveedor,ped.estado_gestion,
                              dp.cantidad_solicitada-COALESCE((SELECT SUM(e.cantidad) FROM entrada_stock e WHERE e.id_detalle_pedido=dp.id_detalle_pedido),0) AS pendiente
                              FROM detalle_pedido dp JOIN pedido ped ON ped.id_pedido=dp.id_pedido
                              WHERE dp.id_detalle_pedido=?''',(entero(linea_id,'Línea de pedido',1),)).fetchone()
            if linea is None or linea['estado_gestion']!='EMITIDO' or cantidad>linea['pendiente']:
                raise ErrorOperacion('La línea de pedido no existe, está cancelada o excede la cantidad pendiente.')
            producto=linea['id_producto']
            if datos.get('id_producto') and entero(datos.get('id_producto'),'Producto',1)!=producto:
                raise ErrorOperacion('La línea de pedido corresponde a otro producto.')
            proveedor=linea['id_proveedor']
        else:
            producto=id_valido(con,'producto','id_producto',datos.get('id_producto'))['id_producto']
            proveedor=id_valido(con,'proveedor','id_proveedor',datos.get('id_proveedor'))['id_proveedor'] if datos.get('id_proveedor') else None
            linea_id=None
        cur=con.execute('''INSERT INTO entrada_stock(id_producto,id_proveedor,id_detalle_pedido,tipo_entrada,cantidad,costo_unitario,referencia_documento,observacion)
                           VALUES(?,?,?,?,?,?,?,?)''',
                        (producto,proveedor,linea_id,tipo,cantidad,costo,texto(datos,'referencia_documento',100) or None,texto(datos,'observacion',500) or None))
        return cur.lastrowid

def resumen_jornada(con, fecha):
    return con.execute('''SELECT COUNT(DISTINCT f.id_venta) AS ventas,
        COALESCE(SUM(d.cantidad),0) AS unidades,
        COALESCE(SUM(d.cantidad*d.precio_unitario),0) AS total_clp
        FROM sig_folio_venta f LEFT JOIN detalle_venta d ON d.id_venta=f.id_venta
        WHERE f.fecha_local=?''',(fecha,)).fetchone()

def jornada_actual(con, fecha=None):
    fecha=fecha or hoy_chile()
    return con.execute('SELECT * FROM sig_jornada WHERE fecha_local=?',(fecha,)).fetchone()

def guardar_venta(datos):
    productos=datos.getlist('id_producto')
    cantidades=datos.getlist('cantidad')
    if not productos or len(productos)!=len(cantidades) or len(productos)>80:
        raise ErrorOperacion('La venta debe contener entre 1 y 80 productos.')
    origenes=datos.getlist('modo_identificacion')
    if origenes and len(origenes)!=len(productos):
        raise ErrorOperacion('La identificación de los productos no coincide con las líneas de venta.')
    items=[];seen=set()
    for pos,(p,q) in enumerate(zip(productos,cantidades)):
        identificador=entero(p,'Producto',1)
        if identificador in seen: raise ErrorOperacion('Un producto aparece dos veces en la venta.')
        seen.add(identificador)
        origen=origenes[pos] if origenes else None
        if origen not in (None,'barras','manual'):
            raise ErrorOperacion('Modo de identificación no válido.')
        items.append((identificador,entero(q,'Cantidad vendida',1),origen))
    with escritura() as con:
        fecha=hoy_chile()
        jornada=jornada_actual(con,fecha)
        if jornada is not None and jornada['estado']=='CERRADA':
            raise ErrorOperacion('La jornada de hoy está cerrada. Reábrela expresamente antes de vender.')
        precios=[]
        for id_producto,cantidad,origen in items:
            p=id_valido(con,'producto','id_producto',id_producto,True)
            if origen=='manual' and p['codigo_barras'] is not None:
                raise ErrorOperacion('La búsqueda manual de ventas permite solo productos sin código de barras.')
            if origen=='barras' and p['codigo_barras'] is None:
                raise ErrorOperacion('El producto no tiene código de barras registrado.')
            if cantidad>p['stock_actual']:
                raise ErrorOperacion(f'Stock insuficiente para {p["nombre"]}. Disponible: {p["stock_actual"]}.')
            precios.append((id_producto,cantidad,p['precio_venta'],p['costo_promedio']))
        con.execute("INSERT OR IGNORE INTO sig_jornada(fecha_local,estado) VALUES(?,'ABIERTA')",(fecha,))
        siguiente=con.execute('SELECT COALESCE(MAX(secuencia),0)+1 FROM sig_folio_venta WHERE fecha_local=?',(fecha,)).fetchone()[0]
        if siguiente>9999:
            raise ErrorOperacion('Se agotaron los 9.999 folios diarios. Contacta a soporte.')
        venta_fecha=ahora_utc_sql()
        cur=con.execute('INSERT INTO venta(fecha_hora,observacion) VALUES(?,?)',(venta_fecha,texto(datos,'observacion',500) or None))
        venta_id=cur.lastrowid
        con.execute('INSERT INTO sig_folio_venta(id_venta,fecha_local,secuencia,folio) VALUES(?,?,?,?)',
                    (venta_id,fecha,siguiente,folio(fecha,siguiente)))
        for id_producto,cantidad,precio,cpp in precios:
            con.execute('INSERT INTO detalle_venta(id_venta,id_producto,cantidad,precio_unitario,costo_unitario_cpp) VALUES(?,?,?,?,?)',
                        (venta_id,id_producto,cantidad,precio,cpp))
        # Pagos y líneas se guardan en una única transacción SQLite.
        medio=texto(datos,'medio_pago',20)
        if medio:
            if medio not in ('EFECTIVO','TRANSBANK','MIXTO'):
                raise ErrorOperacion('Método de pago no válido.')
            total=sum(cantidad*precio for _,cantidad,precio,_ in precios)
            if medio=='EFECTIVO':
                efectivo,tarjeta=total,0
            elif medio=='TRANSBANK':
                efectivo,tarjeta=0,total
            else:
                efectivo=entero(datos.get('monto_efectivo'),'Pago en efectivo')
                tarjeta=entero(datos.get('monto_transbank'),'Pago con Transbank')
                if efectivo<=0 or tarjeta<=0:
                    raise ErrorOperacion('El pago mixto requiere ambos montos positivos.')
            if efectivo+tarjeta!=total:
                raise ErrorOperacion('La suma de medios de pago debe ser igual al total de la venta.')
            if tarjeta and datos.get('transbank_confirmado')!='1':
                raise ErrorOperacion('Confirma primero que el terminal Transbank aprobó el pago.')
            ref=texto(datos,'referencia_transbank',100) or None
            tipo=texto(datos,'tipo_tarjeta',20) or None
            if tipo and tipo not in ('DEBITO','CREDITO','PREPAGO','NO_IDENTIFICADO'):
                raise ErrorOperacion('Tipo de tarjeta no válido.')
            if efectivo:
                con.execute('INSERT INTO sig_pago_venta(id_venta,medio,monto_clp,registrado_utc) VALUES(?,?,?,?)',
                            (venta_id,'EFECTIVO',efectivo,venta_fecha))
            if tarjeta:
                con.execute('INSERT INTO sig_pago_venta(id_venta,medio,monto_clp,referencia,tipo_tarjeta,confirmado,registrado_utc) VALUES(?,?,?,?,?,1,?)',
                            (venta_id,'TRANSBANK',tarjeta,ref,tipo,venta_fecha))
        return venta_id

def cerrar_jornada(validar_caja=False, excepcion=""):
    # La pantalla de cierre exige arqueo; llamadas anteriores siguen compatibles.
    with escritura() as con:
        fecha=hoy_chile()
        anterior=jornada_actual(con,fecha)
        if anterior is not None and anterior['estado']=='CERRADA':
            return resumen_jornada(con,fecha), False
        r=resumen_jornada(con,fecha)
        if validar_caja:
            from caja import validar_cierre
            validar_cierre(con,fecha,excepcion)
            if excepcion.strip():
                con.execute('INSERT OR IGNORE INTO sig_arqueo_caja(fecha_local,fondo_inicial_clp,contado_clp,esperado_clp,diferencia_clp,actualizado_utc) VALUES(?,0,0,0,0,?)', (fecha,ahora_utc_sql()))
                con.execute('UPDATE sig_arqueo_caja SET excepcion_cierre=? WHERE fecha_local=?',(excepcion.strip()[:500],fecha))
        con.execute("INSERT OR IGNORE INTO sig_jornada(fecha_local,estado) VALUES(?,'ABIERTA')",(fecha,))
        instante=ahora_utc_sql()
        con.execute('''UPDATE sig_jornada SET estado='CERRADA',cerrado_utc=?,
                   ventas_cierre=?,unidades_cierre=?,total_cierre=? WHERE fecha_local=?''',
                    (instante,r['ventas'],r['unidades'],r['total_clp'],fecha))
        con.execute('''INSERT INTO sig_evento_jornada(fecha_local,accion,fecha_hora_utc,ventas,unidades,total_clp)
                       VALUES(?,'CIERRE',?,?,?,?)''',(fecha,instante,r['ventas'],r['unidades'],r['total_clp']))
        return r, True

def reabrir_jornada(confirmacion):
    if confirmacion!='REABRIR':
        raise ErrorOperacion('Escribe REABRIR para confirmar la reapertura.')
    with escritura() as con:
        fecha=hoy_chile()
        actual=jornada_actual(con,fecha)
        if actual is None or actual['estado']!='CERRADA':
            raise ErrorOperacion('La jornada de hoy no está cerrada.')
        instante=ahora_utc_sql()
        con.execute("UPDATE sig_jornada SET estado='ABIERTA',reaperturas=reaperturas+1 WHERE fecha_local=?",(fecha,))
        con.execute('''INSERT INTO sig_evento_jornada(fecha_local,accion,fecha_hora_utc,ventas,unidades,total_clp)
                       VALUES(?,'REAPERTURA',?,?,?,?)''',
                    (fecha,instante,actual['ventas_cierre'],actual['unidades_cierre'],actual['total_cierre']))
        return fecha

def guardar_ajuste(datos):
    tipo=texto(datos,'tipo_ajuste',20,True)
    if tipo not in ('MERMA','CORRECCION'): raise ErrorOperacion('Tipo de ajuste no válido.')
    cantidad=delta_entero(datos.get('cantidad_delta'))
    if tipo=='MERMA' and cantidad>=0: raise ErrorOperacion('Una merma debe descontar unidades.')
    motivo=texto(datos,'motivo',500,True)
    with escritura() as con:
        p=id_valido(con,'producto','id_producto',datos.get('id_producto'))
        if p['stock_actual']+cantidad<0:
            raise ErrorOperacion('El ajuste dejaría el inventario con stock negativo.')
        cur=con.execute('INSERT INTO ajuste_inventario(id_producto,tipo_ajuste,cantidad_delta,motivo,costo_unitario_cpp) VALUES(?,?,?,?,?)',
                        (p['id_producto'],tipo,cantidad,motivo,p['costo_promedio']))
        return cur.lastrowid

def guardar_conteo(datos):
    cantidad=entero(datos.get('cantidad_fisica'),'Cantidad física',0)
    with escritura() as con:
        p=id_valido(con,'producto','id_producto',datos.get('id_producto'))
        cur=con.execute('INSERT INTO conteo_fisico(id_producto,stock_sistema,cantidad_fisica,observacion) VALUES(?,?,?,?)',
                        (p['id_producto'],p['stock_actual'],cantidad,texto(datos,'observacion',500) or None))
        return cur.lastrowid
