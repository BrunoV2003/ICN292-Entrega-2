"""Respaldo semanal local verificable con retención de 60 días.

No instala ninguna tarea: puede ejecutarse a mano o desde Programador de tareas.
Nunca borra la última copia válida ni copias manuales o de nombres ajenos.
"""
from datetime import timedelta, datetime
from contextlib import closing
from pathlib import Path
import re
import sqlite3
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import db
from reloj import ahora_chile, CHILE

RAIZ=Path(__file__).resolve().parents[1]
PATRON=re.compile(r'^minimarket_auto_(\d{8})_(\d{6})_(\d{6})\.db$')

def respaldar(carpeta=None, dias=60, reloj=None):
    ahora=reloj or ahora_chile()
    carpeta=Path(carpeta or (Path(__import__('os').environ.get('SIG_DATA_DIR') or (db.ruta_bd().parent))/'respaldos'))
    carpeta.mkdir(parents=True, exist_ok=True)
    nombre='minimarket_auto_'+ahora.strftime('%Y%m%d_%H%M%S_%f')+'.db'
    temporal=carpeta/(nombre+'.tmp')
    destino=carpeta/nombre
    log=carpeta/'historial_respaldos.log'
    try:
        if temporal.exists() or destino.exists():
            raise FileExistsError('Ya existe un respaldo con este nombre.')
        with db.lectura() as origen:
            with closing(sqlite3.connect(temporal)) as copia:
                origen.backup(copia)
                if copia.execute('PRAGMA quick_check').fetchone()[0]!='ok':
                    raise RuntimeError('quick_check falló en el respaldo.')
                if copia.execute('PRAGMA foreign_key_check').fetchall():
                    raise RuntimeError('foreign_key_check falló en el respaldo.')
        temporal.replace(destino)
        borrados=limpiar(carpeta, ahora, dias)
        mensaje=f'{ahora.isoformat()} OK {nombre} {destino.stat().st_size} bytes; eliminados={len(borrados)}: {", ".join(borrados)}'
        with log.open('a',encoding='utf-8') as archivo:archivo.write(mensaje+'\n')
        return destino, borrados
    except BaseException as ex:
        temporal.unlink(missing_ok=True)
        with log.open('a',encoding='utf-8') as archivo:archivo.write(f'{ahora.isoformat()} ERROR {type(ex).__name__}: {ex}\n')
        raise

def limpiar(carpeta, ahora, dias=60):
    archivos=[]
    for p in Path(carpeta).iterdir():
        if not p.is_file() or p.is_symlink():continue
        m=PATRON.fullmatch(p.name)
        if not m:continue
        try:
            fecha=datetime.strptime(m.group(1)+m.group(2)+m.group(3),'%Y%m%d%H%M%S%f').replace(tzinfo=CHILE)
        except ValueError:continue
        try:
            with closing(sqlite3.connect(p.as_uri()+'?mode=ro',uri=True)) as con:
                con.row_factory=sqlite3.Row
                db.verificar_esquema(con)
                if con.execute('PRAGMA quick_check').fetchone()[0]!='ok':continue
                if con.execute('PRAGMA foreign_key_check').fetchall():continue
        except (sqlite3.Error,db.EsquemaIncompatible,OSError):
            continue
        archivos.append((fecha,p))
    archivos.sort(reverse=True)
    protegidos={p for _,p in archivos[:2]}
    corte=ahora-timedelta(days=dias)
    borrados=[]
    for fecha,p in archivos:
        if p in protegidos or fecha>=corte:continue
        # Se borran únicamente archivos del patrón propio; no se sigue ningún enlace.
        p.unlink();borrados.append(p.name)
    return borrados

if __name__=='__main__':
    dest,removed=respaldar()
    print('Respaldo creado y verificado:',dest)
    print('Copias antiguas eliminadas:',len(removed))
