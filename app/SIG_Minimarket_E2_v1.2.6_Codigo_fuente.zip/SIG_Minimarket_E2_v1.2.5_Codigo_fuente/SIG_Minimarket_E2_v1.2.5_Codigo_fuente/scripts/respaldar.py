"""Respaldo manual consistente de SQLite; conserva todas las copias previas."""
from pathlib import Path
from contextlib import closing
import os
import sqlite3
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import db
from reloj import ahora_chile


def main():
    ruta = db.ruta_bd()
    if not ruta.is_file():
        print('No existe la base del SIG.', file=sys.stderr)
        return 1
    raiz = Path(os.environ.get('SIG_DATA_DIR') or Path(__file__).resolve().parents[1])
    carpeta = raiz / 'respaldos'
    carpeta.mkdir(parents=True, exist_ok=True)
    nombre = ahora_chile().strftime('minimarket_%Y%m%d_%H%M%S_%f.db')
    destino = carpeta / nombre
    temporal = carpeta / (nombre + '.tmp')
    try:
        if destino.exists() or temporal.exists():
            raise FileExistsError('El archivo de respaldo ya existe.')
        with db.lectura() as origen, closing(sqlite3.connect(temporal)) as copia:
            origen.backup(copia)
            if copia.execute('PRAGMA quick_check').fetchone()[0] != 'ok':
                raise RuntimeError('Respaldo con error de integridad.')
            if copia.execute('PRAGMA foreign_key_check').fetchall():
                raise RuntimeError('Respaldo con errores de claves foraneas.')
        temporal.replace(destino)
        print('Respaldo manual creado:', destino)
        return 0
    except BaseException as error:
        temporal.unlink(missing_ok=True)
        print(f'ERROR al respaldar: {error}', file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
