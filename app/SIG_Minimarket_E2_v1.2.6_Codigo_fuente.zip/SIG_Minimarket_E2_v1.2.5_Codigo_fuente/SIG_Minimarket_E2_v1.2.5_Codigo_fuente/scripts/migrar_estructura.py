"""Instala metadatos aditivos para folios y jornadas en la MISMA base SQLite.

No cambia ni elimina las nueve tablas comerciales, las cinco vistas, ni los triggers.
Ejecutar ANTES de reemplazar una base antigua y siempre tras hacer respaldo.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import sqlite3
import db
from reloj import fecha_chile_sql, folio

DDL = '''
CREATE TABLE IF NOT EXISTS sig_folio_venta (
 id_venta INTEGER PRIMARY KEY REFERENCES venta(id_venta) ON DELETE RESTRICT,
 fecha_local TEXT NOT NULL,
 secuencia INTEGER NOT NULL CHECK(secuencia > 0),
 folio TEXT NOT NULL UNIQUE,
 UNIQUE(fecha_local,secuencia)
);
CREATE TABLE IF NOT EXISTS sig_jornada (
 fecha_local TEXT PRIMARY KEY,
 estado TEXT NOT NULL CHECK(estado IN ('ABIERTA','CERRADA')),
 cerrado_utc TEXT,
 ventas_cierre INTEGER,
 unidades_cierre INTEGER,
 total_cierre INTEGER,
 reaperturas INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS sig_evento_jornada (
 id_evento INTEGER PRIMARY KEY,
 fecha_local TEXT NOT NULL REFERENCES sig_jornada(fecha_local),
 accion TEXT NOT NULL CHECK(accion IN ('CIERRE','REAPERTURA')),
 fecha_hora_utc TEXT NOT NULL,
 ventas INTEGER,
 unidades INTEGER,
 total_clp INTEGER
);
'''

def migrar(ruta=None):
    ruta=Path(ruta or db.ruta_bd())
    if not ruta.is_file():
        raise FileNotFoundError(f'Base inexistente: {ruta}')
    con=sqlite3.connect(str(ruta), timeout=15)
    con.row_factory=sqlite3.Row
    con.execute('PRAGMA foreign_keys=ON')
    con.execute('PRAGMA busy_timeout=15000')
    try:
        con.execute('BEGIN IMMEDIATE')
        db.verificar_esquema(con, exigir_auxiliares=False)
        for stmt in DDL.split(';'):
            if stmt.strip():
                con.execute(stmt)
        filas=con.execute('''SELECT v.id_venta,v.fecha_hora FROM venta v
            LEFT JOIN sig_folio_venta f ON f.id_venta=v.id_venta
            WHERE f.id_venta IS NULL ORDER BY v.fecha_hora,v.id_venta''').fetchall()
        for v in filas:
            dia=fecha_chile_sql(v['fecha_hora'])
            if not dia:
                raise ValueError(f'Venta {v["id_venta"]} con fecha inválida')
            seq=con.execute('SELECT COALESCE(MAX(secuencia),0)+1 FROM sig_folio_venta WHERE fecha_local=?',(dia,)).fetchone()[0]
            con.execute('INSERT INTO sig_folio_venta(id_venta,fecha_local,secuencia,folio) VALUES(?,?,?,?)',
                        (v['id_venta'],dia,seq,folio(dia,seq)))
        # Una ejecución repetida no vuelve a asignar folios.
        if con.execute('PRAGMA quick_check').fetchone()[0]!='ok' or con.execute('PRAGMA foreign_key_check').fetchall():
            raise ValueError('Falló la validación SQLite tras crear los metadatos.')
        con.commit()
        return len(filas)
    except BaseException:
        con.rollback()
        raise
    finally:
        con.close()

if __name__=='__main__':
    print(f'Migración completada. Ventas históricas vinculadas: {migrar()}')
