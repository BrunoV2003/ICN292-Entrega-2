"""Diagnóstico de la BD existente, sin modificarla ni crear tablas."""
from pathlib import Path
import sqlite3
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import db


def verificar():
    with db.lectura() as con:
        estado = db.diagnostico(con)
        estados = {
            tabla: con.execute(f'SELECT COUNT(*) FROM "{tabla}"').fetchone()[0]
            for tabla in sorted(db.TABLAS)
        }
        return estado, estados


def main():
    try:
        estado, estados = verificar()
    except (OSError, sqlite3.Error, db.EsquemaIncompatible) as ex:
        print(f'ERROR: {ex}', file=sys.stderr)
        return 1
    print(f'Base comprobada: {estado["ruta"]}')
    print(f'Integridad SQLite: {estado["integridad"]}')
    print(f'Errores de claves foráneas: {estado["errores_fk"]}')
    print(f'Tablas de negocio: {estado["tablas"]}; vistas: {estado["vistas"]}; triggers: {estado["triggers"]}')
    print('Registros por tabla:')
    for tabla, total in estados.items():
        print(f'  {tabla}: {total}')
    correcto = estado['integridad'] == 'ok' and estado['errores_fk'] == 0
    print('Resultado:', 'CORRECTO' if correcto else 'REVISAR')
    return 0 if correcto else 1


if __name__ == '__main__':
    raise SystemExit(main())
