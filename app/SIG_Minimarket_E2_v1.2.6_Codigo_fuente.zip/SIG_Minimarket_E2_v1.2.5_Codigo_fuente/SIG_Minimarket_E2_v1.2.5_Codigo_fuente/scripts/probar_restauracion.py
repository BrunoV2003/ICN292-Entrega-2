"""Comprueba que un respaldo se puede restaurar en una COPIA TEMPORAL.

No reemplaza la base operativa. Uso opcional:
    python scripts/probar_restauracion.py ruta_del_respaldo.db
Si no se indica archivo, se utiliza el respaldo más reciente en respaldos/.
"""
import os
from contextlib import closing
import sqlite3
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import db



def objetos(con):
    return {
        (row['type'], row['name'], row['sql'])
        for row in con.execute("SELECT type,name,sql FROM sqlite_master WHERE type IN ('table','view','trigger') AND name NOT LIKE 'sqlite_%'")
    }


def datos(con):
    return {tabla: con.execute(f'SELECT COUNT(*) FROM "{tabla}"').fetchone()[0]
            for tabla in sorted(db.TABLAS)}


def probar(origen):
    ruta = Path(origen).expanduser().resolve()
    if not ruta.is_file():
        raise FileNotFoundError(f'El respaldo no existe: {ruta}')
    if ruta == db.ruta_bd():
        raise ValueError('El archivo indicado es la base operativa, no un respaldo independiente.')

    with tempfile.TemporaryDirectory(prefix='sig_restauracion_') as temporal:
        restaurada = Path(temporal) / 'restaurada.db'
        # Se abre en lectura y se crea un NUEVO archivo temporal por backup(),
        # sin copiar o sobreescribir nunca la base de la aplicación.
        with closing(sqlite3.connect(ruta.as_uri() + '?mode=ro', uri=True)) as entrada:
            entrada.row_factory = sqlite3.Row
            entrada.execute('PRAGMA foreign_keys=ON')
            entrada.execute('PRAGMA query_only=ON')
            db.verificar_esquema(entrada)
            if entrada.execute('PRAGMA quick_check').fetchone()[0] != 'ok':
                raise ValueError('El respaldo tiene errores de integridad.')
            if entrada.execute('PRAGMA foreign_key_check').fetchall():
                raise ValueError('El respaldo tiene errores de claves foráneas.')
            originales = objetos(entrada)
            recuentos = datos(entrada)
            with closing(sqlite3.connect(restaurada)) as salida:
                entrada.backup(salida)

        with closing(sqlite3.connect(restaurada.as_uri() + '?mode=ro', uri=True)) as copia:
            copia.row_factory = sqlite3.Row
            copia.execute('PRAGMA foreign_keys=ON')
            copia.execute('PRAGMA query_only=ON')
            db.verificar_esquema(copia)
            assert copia.execute('PRAGMA quick_check').fetchone()[0] == 'ok'
            assert copia.execute('PRAGMA foreign_key_check').fetchall() == []
            if objetos(copia) != originales or datos(copia) != recuentos:
                raise ValueError('Diferencias entre el respaldo y la copia restaurada.')
        return recuentos


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if len(argv) > 1:
        print('Uso: python scripts/probar_restauracion.py [respaldo.db]', file=sys.stderr)
        return 2
    if argv:
        respaldo = Path(argv[0])
    else:
        raiz_datos = Path(os.environ.get('SIG_DATA_DIR') or Path(__file__).resolve().parents[1])
        archivos = sorted((raiz_datos / 'respaldos').glob('minimarket_*.db'))
        if not archivos:
            print('No hay respaldo. Crea primero un respaldo desde el SIG o usa --respaldar.', file=sys.stderr)
            return 1
        respaldo = archivos[-1]
    try:
        resultado = probar(respaldo)
    except (OSError, ValueError, sqlite3.Error, db.EsquemaIncompatible, AssertionError) as ex:
        print(f'ERROR en la prueba de restauración: {ex}', file=sys.stderr)
        return 1
    print('Restauración de prueba: CORRECTA')
    print('Respaldo revisado:', respaldo)
    print('Se comprobaron nueve tablas, cinco vistas, triggers, claves foráneas y registros:')
    for tabla, total in resultado.items():
        print(f'  {tabla}: {total}')
    print('La base operativa NO se modificó. La copia temporal se eliminó tras verificarla.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
