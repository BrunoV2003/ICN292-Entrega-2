"""Prueba integral de negocio en una copia temporal; no necesita Flask ni toca la BD operativa.

Prueba producto -> entrada -> pedido y recepción parcial -> venta de 2 productos
-> merma -> conteo -> alerta. Además, prueba reversión de una venta rechazada,
CPP histórico, persistencia e integridad de las nueve tablas y cinco vistas.
"""
import hashlib
import os
from pathlib import Path
import shutil
import sqlite3
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import db
from operaciones import (ErrorOperacion, guardar_producto, guardar_pedido,
                         guardar_entrada, guardar_venta, guardar_ajuste,
                         guardar_conteo)


class DatosFormulario(dict):
    """Implementación mínima del método getlist usado en formularios Flask."""
    def getlist(self, nombre):
        valor = self.get(nombre, [])
        return valor if isinstance(valor, list) else [valor]


def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for bloque in iter(lambda: f.read(65536), b''):
            h.update(bloque)
    return h.hexdigest()


def consulta(con, sql, args=()):
    return con.execute(sql, args).fetchone()[0]


def prueba():
    operativa = db.ruta_bd()
    huella_inicial = sha256(operativa)
    previo = os.environ.get('SIG_DB_PATH')
    resultados = []
    try:
        with tempfile.TemporaryDirectory(prefix='sig_flujo_') as tmp:
            destino = Path(tmp) / 'prueba.db'
            shutil.copy2(operativa, destino)
            os.environ['SIG_DB_PATH'] = str(destino)
            with db.lectura() as con:
                ids = con.execute('SELECT id_producto,stock_actual FROM producto WHERE activo=1 AND stock_actual>1 ORDER BY stock_actual DESC').fetchall()
                proveedor = consulta(con, 'SELECT id_proveedor FROM proveedor WHERE activo=1 ORDER BY id_proveedor LIMIT 1')
                assert ids, 'La base requiere al menos un producto activo con stock mayor a 1 para la venta de dos líneas.'
                segundo_id = ids[0]['id_producto']
                saldo_segundo = ids[0]['stock_actual']
                cantidad_vendida_antes = consulta(con, 'SELECT COUNT(*) FROM venta')
                fecha_sql = consulta(con, "SELECT date('now')")
            p = guardar_producto({'codigo_interno':'INT-PRUEBA-FLUJO', 'nombre':'Producto temporal de prueba',
                                   'precio_venta':'900', 'stock_minimo':'8', 'activo':'1'})
            with db.lectura() as con:
                assert tuple(con.execute('SELECT stock_actual,costo_promedio FROM producto WHERE id_producto=?',(p,)).fetchone()) == (0,0)
            resultados.append('Alta de producto con stock y CPP en cero: OK')
            guardar_entrada({'tipo_entrada':'CARGA_INICIAL','id_producto':str(p),
                             'cantidad':'7','costo_unitario':'420.25','observacion':'Prueba aislada'})
            with db.lectura() as con:
                stock,cpp=con.execute('SELECT stock_actual,costo_promedio FROM producto WHERE id_producto=?',(p,)).fetchone()
                assert stock == 7 and abs(cpp-420.25)<0.0001
            resultados.append('Carga inicial de 7 unidades y CPP por trigger: OK')
            pedido=guardar_pedido(DatosFormulario({'id_proveedor':str(proveedor),
                            'fecha_entrega_estimada':fecha_sql,
                            'id_producto':[str(p)],'cantidad':['4'],'costo_estimado':['500']}))
            with db.lectura() as con:
                linea=consulta(con,'SELECT id_detalle_pedido FROM detalle_pedido WHERE id_pedido=?',(pedido,))
            guardar_entrada({'tipo_entrada':'RECEPCION','id_detalle_pedido':str(linea),
                             'cantidad':'1','costo_unitario':'500'})
            with db.lectura() as con:
                assert tuple(con.execute('SELECT estado_recepcion,unidades_pendientes FROM v_estado_pedidos WHERE id_pedido=?',(pedido,)).fetchone()) == ('PARCIAL',3)
            try:
                guardar_entrada({'tipo_entrada':'RECEPCION','id_detalle_pedido':str(linea),
                                 'cantidad':'4','costo_unitario':'500'})
            except ErrorOperacion:
                pass
            else:
                raise AssertionError('La recepción excesiva no fue rechazada.')
            guardar_entrada({'tipo_entrada':'RECEPCION','id_detalle_pedido':str(linea),
                             'cantidad':'3','costo_unitario':'500'})
            with db.lectura() as con:
                assert consulta(con,'SELECT estado_recepcion FROM v_estado_pedidos WHERE id_pedido=?',(pedido,))=='RECIBIDO'
                stock,cpp=con.execute('SELECT stock_actual,costo_promedio FROM producto WHERE id_producto=?',(p,)).fetchone()
                assert stock==11
            resultados.append('Pedido, recepción parcial, exceso rechazado y cierre: OK')
            venta=guardar_venta(DatosFormulario({'id_producto':[str(p),str(segundo_id)],'cantidad':['4','1']}))
            with db.lectura() as con:
                assert consulta(con,'SELECT COUNT(*) FROM detalle_venta WHERE id_venta=?',(venta,))==2
                assert consulta(con,'SELECT stock_actual FROM producto WHERE id_producto=?',(p,))==7
                assert consulta(con,'SELECT stock_actual FROM producto WHERE id_producto=?',(segundo_id,))==saldo_segundo-1
                venta_cpp=consulta(con,'SELECT costo_unitario_cpp FROM detalle_venta WHERE id_venta=? AND id_producto=?',(venta,p))
                assert abs(venta_cpp-cpp)<0.0001
                assert consulta(con,'SELECT total_venta_clp FROM v_resumen_venta WHERE id_venta=?',(venta,))>0
            resultados.append('Venta atómica de dos productos, stock y precio/CPP histórico: OK')
            with db.lectura() as con:
                nventas=consulta(con,'SELECT COUNT(*) FROM venta')
                nlineas=consulta(con,'SELECT COUNT(*) FROM detalle_venta')
            try:
                guardar_venta(DatosFormulario({'id_producto':[str(p),str(segundo_id)],
                                               'cantidad':['1',str(saldo_segundo+5)]}))
            except ErrorOperacion:
                pass
            else:
                raise AssertionError('La venta sin stock se aceptó.')
            with db.lectura() as con:
                assert consulta(con,'SELECT COUNT(*) FROM venta')==nventas
                assert consulta(con,'SELECT COUNT(*) FROM detalle_venta')==nlineas
                assert consulta(con,'SELECT stock_actual FROM producto WHERE id_producto=?',(p,))==7
                alerta=con.execute('SELECT estado_alerta,unidades_para_reponer FROM v_alertas_reposicion WHERE id_producto=?',(p,)).fetchone()
                assert alerta is not None and alerta['estado_alerta']=='BAJO_UMBRAL' and alerta['unidades_para_reponer']==2
            resultados.append('Venta fallida revertida y alerta basada en vista SQL: OK')
            guardar_ajuste({'id_producto':str(p),'tipo_ajuste':'MERMA',
                           'cantidad_delta':'-1','motivo':'Merma de prueba'})
            guardar_conteo({'id_producto':str(p),'cantidad_fisica':'5','observacion':'Conteo de prueba'})
            with db.lectura() as con:
                assert consulta(con,'SELECT stock_actual FROM producto WHERE id_producto=?',(p,))==6
                assert tuple(con.execute('SELECT stock_sistema,cantidad_fisica FROM conteo_fisico WHERE id_producto=? ORDER BY id_conteo DESC LIMIT 1',(p,)).fetchone())==(6,5)
                assert consulta(con,'SELECT COUNT(*) FROM v_movimientos_inventario WHERE id_producto=?',(p,))==5
                assert consulta(con,'SELECT COUNT(*) FROM venta')==cantidad_vendida_antes+1
                assert con.execute('PRAGMA quick_check').fetchone()[0]=='ok'
                assert con.execute('PRAGMA foreign_key_check').fetchall()==[]
                db.verificar_esquema(con)
            resultados.append('Merma, conteo independiente e historial: OK')
            resultados.append('Persistencia tras reabrir conexión, 9 tablas y 5 vistas, claves foráneas: OK')
    finally:
        if previo is None:
            os.environ.pop('SIG_DB_PATH',None)
        else:
            os.environ['SIG_DB_PATH']=previo
    if sha256(operativa)!=huella_inicial:
        raise AssertionError('La base operativa cambió durante la prueba.')
    resultados.append('Base operativa sin cambios (SHA-256): OK')
    return resultados


if __name__=='__main__':
    try:
        print('\n'.join(prueba()))
    except Exception as ex:
        print(f'PRUEBA FALLIDA: {ex}', file=sys.stderr)
        raise SystemExit(1)
    print('PRUEBA INTEGRAL CORRECTA')
