"""Inventario de estructura SQL; lectura únicamente, útil para comparar con schema.sql."""
from pathlib import Path
import sys
import sqlite3
import hashlib

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import db


def main():
    try:
        with db.lectura() as con:
            print('Origen SQLite:', db.ruta_bd())
            objetos = con.execute('''SELECT type,name,sql FROM sqlite_master
                    WHERE type IN ('table','view','trigger') AND name NOT LIKE 'sqlite_%'
                    ORDER BY type,name''').fetchall()
            for tipo, nombre, sql in objetos:
                print(f'\n[{tipo}] {nombre}')
                if tipo == 'table':
                    for col in con.execute(f'PRAGMA table_info("{nombre}")'):
                        print(f'    {col[1]}: {col[2]} (NOT NULL={bool(col[3])}, PK={col[5]})')
                print('    SHA-256 definición:', hashlib.sha256((sql or '').encode('utf-8')).hexdigest())
            print(f'\nTotales: {len(db.TABLAS)} tablas SIG, {len(db.VISTAS)} vistas SIG, '
                  f'{sum(o[0] == "trigger" for o in objetos)} triggers.')
    except (OSError, sqlite3.Error, db.EsquemaIncompatible) as ex:
        print(f'ERROR: {ex}', file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
