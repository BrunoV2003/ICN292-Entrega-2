"""Regresión del flujo POS: iniciar -> escanear -> subtotal -> cobrar.

No usa la base operativa: cada test trabaja sobre una copia SQLite temporal.
"""
import os
from pathlib import Path
import re
import shutil
import sqlite3
import tempfile
import unittest
from contextlib import closing
from unittest.mock import patch

from app import app


class FlujoPOSV124(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='sig_pos_v124_')
        self.addCleanup(self.tmp.cleanup)
        self.db=Path(self.tmp.name)/'ensayo.db'
        shutil.copyfile(Path(__file__).resolve().parent/'datos'/'minimarket_prueba.db',self.db)
        self.anterior=os.environ.get('SIG_DB_PATH')
        os.environ['SIG_DB_PATH']=str(self.db)
        self.addCleanup(self.restaurar)
        self.cliente=app.test_client()

    def restaurar(self):
        if self.anterior is None:os.environ.pop('SIG_DB_PATH',None)
        else:os.environ['SIG_DB_PATH']=self.anterior

    def contar(self,tabla):
        with closing(sqlite3.connect(self.db)) as con:
            return con.execute('SELECT COUNT(*) FROM '+tabla).fetchone()[0]

    def test_pantalla_inicial_no_crea_venta_y_muestra_boton(self):
        antes=self.contar('venta')
        html=self.cliente.get('/ventas').get_data(as_text=True)
        self.assertIn('id="comenzar-venta"',html)
        self.assertIn('>Iniciar venta ',html)
        self.assertIn('id="venta-curso" hidden',html)
        self.assertIn('id="subtotal-venta"',html)
        self.assertIn('id="ir-a-cobro"',html)
        self.assertIn('id="lector-venta"',html)
        self.assertIn('id="medio-pago"',html)
        self.assertEqual(antes,self.contar('venta'))

    def test_cobro_mantiene_folio_pago_y_stock_sqlite(self):
        html=self.cliente.get('/ventas').get_data(as_text=True)
        csrf=re.search(r'name="_csrf" value="([^"]+)"',html).group(1)
        nonce=re.search(r'name="nonce" value="([^"]+)"',html).group(1)
        antes=self.contar('venta')
        r=self.cliente.post('/ventas',data={'_csrf':csrf,'nonce':nonce,
                    'id_producto':['1'],'cantidad':['2'],
                    'modo_identificacion':['barras'],'medio_pago':'TRANSBANK',
                    'transbank_confirmado':'1','referencia_transbank':'POS-V124'},follow_redirects=False)
        self.assertEqual(r.status_code,303)
        self.assertEqual(self.contar('venta'),antes+1)
        with closing(sqlite3.connect(self.db)) as con:
            self.assertEqual(con.execute('SELECT COALESCE(SUM(monto_clp),0) FROM sig_pago_venta WHERE referencia=?',('POS-V124',)).fetchone()[0],1400)
            self.assertEqual(con.execute('PRAGMA quick_check').fetchone()[0],'ok')

    def test_no_ofrece_nueva_venta_con_jornada_cerrada(self):
        with patch('app.jornada_actual', return_value={'estado':'CERRADA'}):
            html=self.cliente.get('/ventas').get_data(as_text=True)
        self.assertIn('Jornada cerrada',html)
        self.assertNotIn('id="comenzar-venta"',html)
