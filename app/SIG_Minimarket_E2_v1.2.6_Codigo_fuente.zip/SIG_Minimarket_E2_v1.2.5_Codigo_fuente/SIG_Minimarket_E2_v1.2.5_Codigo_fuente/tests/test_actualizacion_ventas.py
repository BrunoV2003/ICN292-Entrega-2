"""Pruebas nuevas sobre copias temporales de la base original de E2."""
import os
from contextlib import closing
from pathlib import Path
import re
import shutil
import sqlite3
import tempfile
import unittest
from unittest.mock import patch
from datetime import datetime
from zoneinfo import ZoneInfo
from werkzeug.datastructures import MultiDict

from app import app
import db
from operaciones import guardar_producto, guardar_entrada, guardar_venta, cerrar_jornada, reabrir_jornada, ErrorOperacion
from reloj import fecha_chile_sql, folio
from scripts.migrar_estructura import migrar
from scripts.respaldo_semanal import respaldar

SRC=Path(__file__).resolve().parent/'datos'/'minimarket_prueba.db'
CHILE=ZoneInfo('America/Santiago')
class Actualizaciones(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.db=Path(self.temp.name)/'pruebas.db'
        shutil.copy2(SRC,self.db)
        self.old=os.environ.get('SIG_DB_PATH')
        os.environ['SIG_DB_PATH']=str(self.db)
        app.config['TESTING']=True
    def tearDown(self):
        if self.old is None:os.environ.pop('SIG_DB_PATH',None)
        else:os.environ['SIG_DB_PATH']=self.old
        self.temp.cleanup()
    def sql(self,s,a=()):
        with closing(sqlite3.connect(self.db)) as con:
            return con.execute(s,a).fetchall()
    def test_codigo_interno_no_se_escoge_y_es_inmutable(self):
        datos={'codigo_interno':'INT-FORZADO','modo_codigo':'sin','nombre':'Fruta suelta','precio_venta':'800','stock_minimo':'3'}
        id1=guardar_producto(datos)
        c=self.sql('SELECT codigo_interno,codigo_barras,stock_actual FROM producto WHERE id_producto=?',(id1,))[0]
        self.assertTrue(c[0].startswith('INT-'))
        self.assertNotEqual(c[0],'INT-FORZADO')
        self.assertEqual(c[1],None)
        self.assertEqual(c[2],0)
        datos['nombre']='Fruta fresca';guardar_producto(datos,id1)
        self.assertEqual(self.sql('SELECT codigo_interno FROM producto WHERE id_producto=?',(id1,))[0][0],c[0])
        id2=guardar_producto({**datos,'nombre':'Otro producto'})
        self.assertNotEqual(self.sql('SELECT codigo_interno FROM producto WHERE id_producto=?',(id2,))[0][0],c[0])
    def test_barcode_existente_rechazado_y_sin_codigo_no_acepta_barcode(self):
        with self.assertRaises(ErrorOperacion):
            guardar_producto({'modo_codigo':'con','codigo_barras':'7800000000001','nombre':'Repetido','precio_venta':'100','stock_minimo':'1'})
        with self.assertRaises(ErrorOperacion):
            guardar_producto({'modo_codigo':'sin','codigo_barras':'777','nombre':'Incoherente','precio_venta':'100','stock_minimo':'1'})
    def test_folios_en_dia_chile_y_reinicio(self):
        fecha=datetime(2026,11,10,23,59,0,tzinfo=CHILE)
        with patch('reloj.ahora_chile',return_value=fecha):
            primero=guardar_venta(MultiDict([('id_producto','1'),('cantidad','1')]))
            segundo=guardar_venta(MultiDict([('id_producto','1'),('cantidad','1')]))
        self.assertEqual(self.sql('SELECT folio FROM sig_folio_venta WHERE id_venta=?',(primero,))[0][0],'BOL-101120260001')
        self.assertEqual(self.sql('SELECT folio FROM sig_folio_venta WHERE id_venta=?',(segundo,))[0][0],'BOL-101120260002')
        with patch('reloj.ahora_chile',return_value=datetime(2026,11,11,0,1,tzinfo=CHILE)):
            tercero=guardar_venta(MultiDict([('id_producto','1'),('cantidad','1')]))
        self.assertEqual(self.sql('SELECT folio FROM sig_folio_venta WHERE id_venta=?',(tercero,))[0][0],'BOL-111120260001')
    def test_bloqueo_stock_y_folio_no_consumido(self):
        antes=self.sql('SELECT COUNT(*) FROM venta')[0][0]
        with self.assertRaises(ErrorOperacion):
            guardar_venta(MultiDict([('id_producto','1'),('cantidad','99999')]))
        self.assertEqual(self.sql('SELECT COUNT(*) FROM venta')[0][0],antes)
        self.assertEqual(self.sql('SELECT COUNT(*) FROM sig_folio_venta')[0][0],antes)
    def test_cierre_idempotente_y_reapertura_auditada(self):
        t=datetime(2026,11,10,10,0,tzinfo=CHILE)
        with patch('reloj.ahora_chile',return_value=t):
            guardar_venta(MultiDict([('id_producto','1'),('cantidad','2')]))
            r,nuevo=cerrar_jornada()
            self.assertTrue(nuevo)
            self.assertEqual(r['ventas'],1);self.assertEqual(r['unidades'],2)
            self.assertEqual(r['total_clp'],1400)
            r,nuevo=cerrar_jornada();self.assertFalse(nuevo)
            self.assertEqual(self.sql("SELECT COUNT(*) FROM sig_evento_jornada WHERE accion='CIERRE'")[0][0],1)
            with self.assertRaises(ErrorOperacion):guardar_venta(MultiDict([('id_producto','1'),('cantidad','1')]))
            with self.assertRaises(ErrorOperacion):reabrir_jornada('si')
            reabrir_jornada('REABRIR')
            guardar_venta(MultiDict([('id_producto','1'),('cantidad','1')]))
            cerrar_jornada()
        self.assertEqual(self.sql('SELECT COUNT(*) FROM sig_evento_jornada')[0][0],3)
        self.assertEqual(self.sql('SELECT total_cierre FROM sig_jornada WHERE fecha_local=?',('2026-11-10',))[0][0],2100)
    def test_solo_sin_codigo_por_buscador_ventas(self):
        with self.assertRaises(ErrorOperacion):
            guardar_venta(MultiDict([('id_producto','1'),('cantidad','1'),('modo_identificacion','manual')]))
        # Producto 7 puede o no tener código: creamos uno sin él y le ingresamos stock.
        id1=guardar_producto({'modo_codigo':'sin','nombre':'Pan suelto','precio_venta':'100','stock_minimo':'1'})
        guardar_entrada({'tipo_entrada':'CARGA_INICIAL','id_producto':str(id1),'cantidad':'3','costo_unitario':'30'})
        venta=guardar_venta(MultiDict([('id_producto',str(id1)),('cantidad','2'),('modo_identificacion','manual')]))
        self.assertEqual(self.sql('SELECT cantidad FROM detalle_venta WHERE id_venta=?',(venta,))[0][0],2)
    def test_linea_pedido_no_se_puede_desviar_a_otro_producto(self):
        r=self.sql('''SELECT dp.id_detalle_pedido,dp.id_producto FROM detalle_pedido dp
            JOIN pedido pe ON pe.id_pedido=dp.id_pedido WHERE pe.estado_gestion='EMITIDO'
            LIMIT 1''')[0]
        con_id=r[1]
        otro=2 if con_id!=2 else 1
        with self.assertRaises(ErrorOperacion):
            guardar_entrada({'tipo_entrada':'RECEPCION','id_detalle_pedido':str(r[0]),'id_producto':str(otro),'cantidad':'1','costo_unitario':'50'})
    def test_api_scan_y_vistas(self):
        with app.test_client() as client:
            for ruta in ['/','/ventas','/ventas/cierre','/entradas/nueva','/reposicion','/productos/nuevo','/reportes']:
                self.assertEqual(client.get(ruta).status_code,200,ruta)
            r=client.get('/api/productos/codigo?codigo=7800000000001')
            self.assertEqual(r.status_code,200)
            self.assertEqual(r.json['id_producto'],1)
            self.assertEqual(client.get('/api/productos/codigo?codigo=noexiste').status_code,404)
            html=client.get('/ventas').get_data(as_text=True)
            # En el POS nuevo la búsqueda manual se despliega después de
            # pulsar «Iniciar venta». Se conserva el acceso a productos sin código.
            self.assertIn('id="comenzar-venta"',html)
            self.assertIn('id="venta-curso" hidden',html)
            self.assertIn('id="mostrar-manual"',html)
            self.assertIn('Buscar producto sin código de barras',html)
            self.assertIn('id="producto-manual"',html)
            self.assertIn('id="agregar-manual"',html)
            self.assertIn('Finalizar día',html)
            self.assertIn('BOL-',html)
            self.assertIn('Modo reposición',client.get('/').get_data(as_text=True))
    def test_venta_web_dos_productos_cierre_y_pin(self):
        fecha=datetime(2026,11,10,15,0,tzinfo=CHILE)
        with patch('reloj.ahora_chile',return_value=fecha),app.test_client() as client:
            html=client.get('/ventas').get_data(as_text=True)
            csrf=re.search(r'name="_csrf" value="([^"]+)"',html).group(1)
            nonce=re.search(r'name="nonce" value="([^"]+)"',html).group(1)
            r=client.post('/ventas/nueva',data={'_csrf':csrf,'nonce':nonce,'id_producto':['1','4'],
                'cantidad':['1','2'],'modo_identificacion':['barras','manual'],'medio_pago':'EFECTIVO'})
            self.assertEqual(r.status_code,303)
            destino=r.headers['Location']
            self.assertTrue(destino.startswith('/ventas/'))
            detalle=client.get(destino).get_data(as_text=True)
            self.assertIn('BOL-101120260001',detalle)
            self.assertEqual(self.sql('SELECT COUNT(*) FROM detalle_venta WHERE id_venta=5')[0][0],2)
            from caja import resumen_pagos
            import db
            with db.lectura() as con: efectivo=resumen_pagos(con,'2026-11-10')['efectivo']
            r=client.post('/ventas/cierre/arqueo',data={'_csrf':csrf,'fondo_inicial_clp':'0',
                'ingresos_clp':'0','retiros_clp':'0','contado_clp':str(efectivo)})
            self.assertEqual(r.status_code,303)
            r=client.post('/ventas/cierre',data={'_csrf':csrf,'confirmar':'SI'})
            self.assertEqual(r.status_code,303)
            cierre=client.get('/ventas/cierre').get_data(as_text=True)
            self.assertIn('CERRADA',cierre)
            r=client.post('/ventas/reabrir',data={'_csrf':csrf,'confirmacion':'REABRIR','pin':'incorrecto'})
            self.assertEqual(r.status_code,303)
            with patch.dict(os.environ,{'SIG_ADMIN_PIN':'654321'}):
                r=client.post('/ventas/reabrir',data={'_csrf':csrf,'confirmacion':'REABRIR','pin':'654321'})
                self.assertEqual(r.status_code,303)
            self.assertEqual(self.sql("SELECT estado FROM sig_jornada WHERE fecha_local='2026-11-10'")[0][0],'ABIERTA')
    def test_backup_fallido_no_borra_copias(self):
        carpeta=Path(self.temp.name)/'fallos';carpeta.mkdir()
        antiguo=carpeta/'minimarket_auto_20260101_040000_000000.db'
        shutil.copy2(self.db,antiguo)
        os.environ['SIG_DB_PATH']=str(Path(self.temp.name)/'NO_EXISTE.db')
        try:
            with self.assertRaises(FileNotFoundError):
                respaldar(carpeta=carpeta,reloj=datetime(2026,11,10,4,tzinfo=CHILE))
        finally:
            os.environ['SIG_DB_PATH']=str(self.db)
        self.assertTrue(antiguo.exists())
        self.assertIn('ERROR',(carpeta/'historial_respaldos.log').read_text())
    def test_reporte_con_hora_chilena(self):
        self.assertEqual(fecha_chile_sql('2026-11-11 01:00:00'),'2026-11-10')
        self.assertEqual(fecha_chile_sql('2026-07-11 02:00:00'),'2026-07-10')
        self.assertEqual(folio('2026-11-10',1),'BOL-101120260001')
        with app.test_client() as c:
            self.assertEqual(c.get('/reportes?tipo=ingresos&desde=2026-11-09&hasta=2026-11-10').status_code,200)
    def test_migracion_repetible(self):
        with closing(sqlite3.connect(self.db)) as con, con:
            con.execute('DROP TABLE sig_evento_jornada');con.execute('DROP TABLE sig_jornada');con.execute('DROP TABLE sig_folio_venta')
        self.assertEqual(migrar(self.db),4)
        self.assertEqual(migrar(self.db),0)
        self.assertEqual(self.sql('SELECT COUNT(*) FROM sig_folio_venta')[0][0],4)
    def test_backup_valido_y_retencion(self):
        fecha=datetime(2026,11,10,4,0,0,tzinfo=CHILE)
        carpeta=Path(self.temp.name)/'copias'
        # Copias antiguas de la misma app y un archivo ajeno no se deben confundir.
        for stamp in ('20260801_040000_000000','20261010_040000_000000','20261103_040000_000000'):
            p=carpeta/('minimarket_auto_'+stamp+'.db');p.parent.mkdir(exist_ok=True)
            shutil.copy2(self.db,p)
        extra=carpeta/'guardar_para_siempre.db';extra.write_bytes(b'no borrar')
        destino,borrados=respaldar(carpeta=carpeta,reloj=fecha)
        self.assertTrue(destino.is_file())
        self.assertEqual(self.sql('PRAGMA quick_check')[0][0],'ok')
        self.assertIn('minimarket_auto_20260801_040000_000000.db',borrados)
        self.assertNotIn('minimarket_auto_20261010_040000_000000.db',borrados)
        self.assertTrue((carpeta/'minimarket_auto_20261010_040000_000000.db').exists()) # retención 60 días
        self.assertTrue(extra.exists())
        self.assertTrue((carpeta/'minimarket_auto_20261103_040000_000000.db').exists())
        self.assertTrue((carpeta/'historial_respaldos.log').exists())

if __name__=='__main__':unittest.main()
