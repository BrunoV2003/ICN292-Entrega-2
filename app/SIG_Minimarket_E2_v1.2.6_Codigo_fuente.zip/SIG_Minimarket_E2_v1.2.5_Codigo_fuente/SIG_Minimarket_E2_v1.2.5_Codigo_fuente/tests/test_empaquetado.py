"""Pruebas del modo ejecutable; no dependen de Flask ni tocan la base real."""
import hashlib
from contextlib import closing
import os
from pathlib import Path
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

RAIZ = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RAIZ))
import sig_windows


class TestEmpaquetado(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='sig_ejecutable_')
        self.addCleanup(self.tmp.cleanup)
        self.dir = Path(self.tmp.name)
        self.data = self.dir / 'user_data'
        self.previous = {k: os.environ.get(k) for k in ('SIG_DB_PATH','SIG_DATA_DIR')}
        self.addCleanup(self.restaurar_entorno)
        os.environ.pop('SIG_DB_PATH', None)
        os.environ['SIG_DATA_DIR'] = str(self.data)

    def restaurar_entorno(self):
        for k, previo in self.previous.items():
            if previo is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = previo

    def sha(self, f):
        return hashlib.sha256(f.read_bytes()).hexdigest()

    def test_base_distribuida_esta_vacia(self):
        """La version final no incluye datos de demostracion."""
        with closing(sqlite3.connect((RAIZ/'database'/'minimarket.db').as_uri() + '?mode=ro', uri=True)) as con:
            tablas = [t for (t,) in con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")]
            self.assertTrue(tablas)
            for tabla in tablas:
                self.assertEqual(con.execute(f'SELECT count(*) FROM "{tabla}"').fetchone()[0], 0, tabla)

    def test_primera_instalacion_no_sobrescribe_ni_toca_base_inicial(self):
        muestra = RAIZ / 'database' / 'minimarket.db'
        huella_demo = self.sha(muestra)
        db = sig_windows.preparar_base()
        self.assertTrue(db.exists())
        self.assertEqual(self.sha(muestra), huella_demo)
        self.assertFalse((self.data/'IMPORTANTE_BASE_DEMOSTRACION.txt').exists())
        with closing(sqlite3.connect(db)) as con, con:
            con.execute("INSERT INTO proveedor(nombre) VALUES ('Proveedor de prueba')")
            con.commit()
        huella_actual = self.sha(db)
        os.environ.pop('SIG_DB_PATH')
        self.assertEqual(db, sig_windows.preparar_base())
        self.assertEqual(self.sha(db), huella_actual)
        self.assertEqual(self.sha(muestra), huella_demo)

    def test_verificacion_cierra_conexion_sqlite(self):
        """En Windows el archivo de prueba debe poder borrarse inmediatamente."""
        muestra = RAIZ / 'database' / 'minimarket.db'
        reales = sqlite3.connect
        abiertas = []

        def registrar(*args, **kwargs):
            con = reales(*args, **kwargs)
            abiertas.append(con)
            return con

        with patch('sig_windows.sqlite3.connect', side_effect=registrar):
            sig_windows.verificar_base_archivo(muestra)

        self.assertTrue(abiertas)
        for con in abiertas:
            with self.assertRaises(sqlite3.ProgrammingError):
                con.execute('SELECT 1')

    def test_ruta_explicita_no_crea_archivos(self):
        ruta = self.dir / 'inexistente.db'
        os.environ['SIG_DB_PATH'] = str(ruta)
        with self.assertRaises(FileNotFoundError):
            sig_windows.preparar_base()
        self.assertFalse(ruta.exists())
        self.assertFalse(self.data.exists())

    def test_ruta_explicita_prioritaria(self):
        real = self.dir / 'datos_existentes.db'
        shutil.copyfile(RAIZ/'database'/'minimarket.db', real)
        os.environ['SIG_DB_PATH'] = str(real)
        huella = self.sha(real)
        self.assertEqual(sig_windows.preparar_base(), real)
        self.assertEqual(huella, self.sha(real))
        self.assertFalse(self.data.exists())

    def test_respaldo_y_restauracion_no_cambian_base(self):
        db = sig_windows.preparar_base()
        antes = self.sha(db)
        self.assertEqual(sig_windows.main(['--respaldar']), 0)
        respaldo = list((self.data/'respaldos').glob('minimarket_*.db'))
        self.assertEqual(len(respaldo), 1)
        self.assertEqual(sig_windows.main(['--probar-restauracion']), 0)
        self.assertEqual(sig_windows.main(['--verificar']), 0)
        self.assertEqual(antes, self.sha(db))

    def test_no_se_acepta_base_corrupta(self):
        mala = self.dir / 'mala.db'
        mala.write_bytes(b'no soy SQLite')
        os.environ['SIG_DB_PATH'] = str(mala)
        with self.assertRaises(sqlite3.DatabaseError):
            sig_windows.preparar_base()
        self.assertEqual(mala.read_bytes(), b'no soy SQLite')

if __name__ == '__main__':
    unittest.main()
