"""Pruebas reproducibles con COPIAS TEMPORALES de la SQLite recibida."""
import os
from pathlib import Path
import shutil
import sqlite3
import tempfile
import unittest
from uuid import uuid4
from werkzeug.datastructures import MultiDict

import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from app import app
from db import conectar, EsquemaIncompatible
from reloj import hoy_chile
from operaciones import (guardar_entrada, guardar_producto, guardar_proveedor,
     guardar_pedido, guardar_venta, guardar_ajuste, guardar_conteo,
     ErrorOperacion, cancelar_pedido)

ORIGEN=Path(__file__).resolve().parent/'datos'/'minimarket_prueba.db'

class SIGPruebas(unittest.TestCase):
    def setUp(self):
        self.carpeta=tempfile.TemporaryDirectory()
        self.db=Path(self.carpeta.name)/'prueba.db'
        shutil.copy2(ORIGEN,self.db)
        self.prev=os.environ.get('SIG_DB_PATH')
        os.environ['SIG_DB_PATH']=str(self.db)
        app.config['TESTING']=True

    def tearDown(self):
        if self.prev is None:os.environ.pop('SIG_DB_PATH',None)
        else:os.environ['SIG_DB_PATH']=self.prev
        self.carpeta.cleanup()

    def consulta(self,sql,param=()):
        con=sqlite3.connect(self.db)
        try:return con.execute(sql,param).fetchall()
        finally:con.close()

    def test_integridad_y_objetos_originales(self):
        con=conectar()
        try:
            self.assertEqual(con.execute('PRAGMA foreign_keys').fetchone()[0],1)
            self.assertEqual(con.execute('PRAGMA quick_check').fetchone()[0],'ok')
            self.assertEqual(con.execute('PRAGMA foreign_key_check').fetchall(),[])
            self.assertEqual(con.execute("SELECT count(*) FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").fetchone()[0],12)
            self.assertEqual(con.execute("SELECT count(*) FROM sqlite_master WHERE type='view'").fetchone()[0],5)
        finally:con.close()

    def test_productos_alta_y_codigo_duplicado(self):
        data={'codigo_interno':'INT-NUEVO-01','codigo_barras':'','nombre':'Producto de prueba','precio_venta':'1900','stock_minimo':'4','id_proveedor_principal':'1','activo':'1','stock_actual':'9999','costo_promedio':'9999'}
        nuevo=guardar_producto(data)
        self.assertEqual(self.consulta('SELECT stock_actual,costo_promedio FROM producto WHERE id_producto=?',(nuevo,)),[(0,0)])
        codigo=self.consulta('SELECT codigo_interno FROM producto WHERE id_producto=?',(nuevo,))[0][0]
        self.assertTrue(codigo.startswith('INT-'))
        self.assertNotEqual(codigo,'INT-NUEVO-01')  # El código remitido por el cliente se ignora.
        otro=dict(data, codigo_barras='7800999888777',modo_codigo='con')
        guardar_producto(otro)
        with self.assertRaises(ErrorOperacion): guardar_producto(otro)

    def test_edicion_de_catalogo_no_modifica_stock(self):
        prev=self.consulta('SELECT stock_actual,costo_promedio FROM producto WHERE id_producto=1')[0]
        p=guardar_producto({'codigo_interno':'INT-000001','codigo_barras':'7800000000001','nombre':'Agua nueva','precio_venta':'800','stock_minimo':'5','id_proveedor_principal':'1','activo':'1'},1)
        self.assertEqual(p,1)
        self.assertEqual(self.consulta('SELECT stock_actual,costo_promedio FROM producto WHERE id_producto=1')[0],prev)
        self.assertEqual(self.consulta('SELECT precio_venta FROM producto WHERE id_producto=1'),[(800,)])

    def test_proveedor_nuevo(self):
        p=guardar_proveedor({'nombre':'Proveedor de prueba','plazo_entrega_dias':'4','activo':'1'})
        self.assertEqual(self.consulta('SELECT plazo_entrega_dias FROM proveedor WHERE id_proveedor=?',(p,)),[(4,)])

    def test_pedido_con_dos_lineas(self):
        hoy=hoy_chile()
        datos=MultiDict([('id_proveedor','1'),('fecha_entrega_estimada',hoy),('observacion','Prueba'),('id_producto','1'),('cantidad','3'),('costo_estimado','330.5'),('id_producto','2'),('cantidad','4'),('costo_estimado','700')])
        p=guardar_pedido(datos)
        self.assertEqual(self.consulta('SELECT COUNT(*) FROM detalle_pedido WHERE id_pedido=?',(p,)),[(2,)])
        self.assertEqual(self.consulta('SELECT estado_recepcion FROM v_estado_pedidos WHERE id_pedido=?',(p,)),[('PENDIENTE',)])

    def test_pedido_duplicado_rechaza_todo(self):
        inicial=self.consulta('SELECT COUNT(*) FROM pedido')[0][0]
        hoy=hoy_chile()
        datos=MultiDict([('id_proveedor','1'),('fecha_entrega_estimada',hoy),('id_producto','1'),('cantidad','1'),('costo_estimado',''),('id_producto','1'),('cantidad','1'),('costo_estimado','')])
        with self.assertRaises(ErrorOperacion):guardar_pedido(datos)
        self.assertEqual(self.consulta('SELECT COUNT(*) FROM pedido')[0][0],inicial)

    def test_recepcion_parcial_completa_y_excesiva(self):
        hoy=hoy_chile()
        pedido=guardar_pedido(MultiDict([('id_proveedor','1'),('fecha_entrega_estimada',hoy),('id_producto','1'),('cantidad','5'),('costo_estimado','400')]))
        linea=self.consulta('SELECT id_detalle_pedido FROM detalle_pedido WHERE id_pedido=?',(pedido,))[0][0]
        stock=self.consulta('SELECT stock_actual FROM producto WHERE id_producto=1')[0][0]
        guardar_entrada({'tipo_entrada':'RECEPCION','id_detalle_pedido':str(linea),'cantidad':'2','costo_unitario':'500','observacion':'Parcial'})
        self.assertEqual(self.consulta('SELECT estado_recepcion,unidades_pendientes FROM v_estado_pedidos WHERE id_pedido=?',(pedido,)),[('PARCIAL',3)])
        with self.assertRaises(ErrorOperacion):guardar_entrada({'tipo_entrada':'RECEPCION','id_detalle_pedido':str(linea),'cantidad':'4','costo_unitario':'500'})
        self.assertEqual(self.consulta('SELECT stock_actual FROM producto WHERE id_producto=1'),[(stock+2,)])
        guardar_entrada({'tipo_entrada':'RECEPCION','id_detalle_pedido':str(linea),'cantidad':'3','costo_unitario':'500'})
        self.assertEqual(self.consulta('SELECT estado_recepcion FROM v_estado_pedidos WHERE id_pedido=?',(pedido,)),[('RECIBIDO',)])

    def test_cpp_actualizado_por_trigger_entrada(self):
        previo=self.consulta('SELECT stock_actual,costo_promedio FROM producto WHERE id_producto=1')[0]
        guardar_entrada({'id_producto':'1','id_proveedor':'1','tipo_entrada':'RECEPCION','cantidad':'2','costo_unitario':'600.25'})
        actual=self.consulta('SELECT stock_actual,costo_promedio FROM producto WHERE id_producto=1')[0]
        esperado=round((previo[0]*previo[1]+2*600.25)/(previo[0]+2),4)
        self.assertEqual(actual[0],previo[0]+2)
        self.assertAlmostEqual(actual[1],esperado,4)

    def test_venta_dos_productos_y_cpp_historico(self):
        p1=self.consulta('SELECT stock_actual,precio_venta,costo_promedio FROM producto WHERE id_producto=1')[0]
        p2=self.consulta('SELECT stock_actual,precio_venta,costo_promedio FROM producto WHERE id_producto=2')[0]
        venta=guardar_venta(MultiDict([('id_producto','1'),('cantidad','2'),('id_producto','2'),('cantidad','1')]))
        self.assertEqual(self.consulta('SELECT COUNT(*) FROM detalle_venta WHERE id_venta=?',(venta,)),[(2,)])
        self.assertEqual(self.consulta('SELECT stock_actual FROM producto WHERE id_producto=1'),[(p1[0]-2,)])
        self.assertEqual(self.consulta('SELECT stock_actual FROM producto WHERE id_producto=2'),[(p2[0]-1,)])
        self.assertEqual(self.consulta('SELECT costo_unitario_cpp,precio_unitario FROM detalle_venta WHERE id_venta=? AND id_producto=1',(venta,)),[(p1[2],p1[1])])
        guardar_entrada({'id_producto':'1','tipo_entrada':'RECEPCION','cantidad':'10','costo_unitario':'1000'})
        self.assertEqual(self.consulta('SELECT costo_unitario_cpp FROM detalle_venta WHERE id_venta=? AND id_producto=1',(venta,)),[(p1[2],)])

    def test_venta_sin_stock_rechaza_venta_entera(self):
        stock=self.consulta('SELECT stock_actual FROM producto WHERE id_producto=2')[0][0]
        prev_venta=self.consulta('SELECT COUNT(*) FROM venta')[0][0]
        with self.assertRaises(ErrorOperacion):guardar_venta(MultiDict([('id_producto','1'),('cantidad','1'),('id_producto','2'),('cantidad',str(stock+1))]))
        self.assertEqual(self.consulta('SELECT COUNT(*) FROM venta'),[(prev_venta,)])

    def test_error_trigger_segunda_linea_rollback_todo(self):
        con=sqlite3.connect(self.db)
        con.execute("CREATE TRIGGER tr_test_falla_segunda BEFORE INSERT ON detalle_venta WHEN NEW.id_producto=2 BEGIN SELECT RAISE(ABORT,'Falla simulada'); END")
        con.commit();con.close()
        nventa=self.consulta('SELECT COUNT(*) FROM venta')[0][0]
        cant=self.consulta('SELECT COUNT(*) FROM detalle_venta')[0][0]
        stock=self.consulta('SELECT stock_actual FROM producto WHERE id_producto=1')[0][0]
        with self.assertRaises(sqlite3.IntegrityError):guardar_venta(MultiDict([('id_producto','1'),('cantidad','1'),('id_producto','2'),('cantidad','1')]))
        self.assertEqual(self.consulta('SELECT COUNT(*) FROM venta'),[(nventa,)])
        self.assertEqual(self.consulta('SELECT COUNT(*) FROM detalle_venta'),[(cant,)])
        self.assertEqual(self.consulta('SELECT stock_actual FROM producto WHERE id_producto=1'),[(stock,)])

    def test_ajustes_meras_y_correcciones(self):
        stock=self.consulta('SELECT stock_actual FROM producto WHERE id_producto=1')[0][0]
        guardar_ajuste({'id_producto':'1','tipo_ajuste':'MERMA','cantidad_delta':'-2','motivo':'Merma de prueba'})
        self.assertEqual(self.consulta('SELECT stock_actual FROM producto WHERE id_producto=1'),[(stock-2,)])
        with self.assertRaises(ErrorOperacion):guardar_ajuste({'id_producto':'1','tipo_ajuste':'MERMA','cantidad_delta':str(-stock-100),'motivo':'Exceso'})
        self.assertEqual(self.consulta('SELECT stock_actual FROM producto WHERE id_producto=1'),[(stock-2,)])
        guardar_ajuste({'id_producto':'1','tipo_ajuste':'CORRECCION','cantidad_delta':'3','motivo':'Recuento'})
        self.assertEqual(self.consulta('SELECT stock_actual FROM producto WHERE id_producto=1'),[(stock+1,)])

    def test_conteo_no_mueve_stock(self):
        stock=self.consulta('SELECT stock_actual FROM producto WHERE id_producto=1')[0][0]
        guardar_conteo({'id_producto':'1','cantidad_fisica':str(stock-1),'observacion':'Ejemplo'})
        self.assertEqual(self.consulta('SELECT stock_actual FROM producto WHERE id_producto=1'),[(stock,)])
        self.assertEqual(self.consulta('SELECT stock_sistema,cantidad_fisica FROM conteo_fisico ORDER BY id_conteo DESC LIMIT 1'),[(stock,stock-1)])

    def test_cancelacion_con_recepcion_bloqueada(self):
        with self.assertRaises(sqlite3.IntegrityError):cancelar_pedido(1)

    def test_paginas_y_reportes_en_espanol(self):
        c=app.test_client()
        rutas=['/','/productos','/productos/nuevo','/productos/1/editar','/proveedores','/proveedores/nuevo','/pedidos','/pedidos/nuevo','/pedidos/1','/entradas/nueva','/ventas','/ventas/1','/inventario/ajustes','/inventario/conteos','/alertas','/reportes','/salud']
        for ruta in rutas:
            r=c.get(ruta)
            self.assertEqual(r.status_code,200,ruta+' -> '+str(r.status_code))
            if ruta!='/salud':
                html=r.get_data(as_text=True)
                self.assertIn('lang="es-CL"',html)
                self.assertIn('SIG Minimarket',html)
                self.assertNotIn('€',html)
        for tipo in ('alertas','ingresos','unidades','margen','mermas','conteos','movimientos','reposicion','pedidos','pendientes'):
            r=c.get('/reportes?tipo='+tipo)
            self.assertEqual(r.status_code,200,(tipo,r.get_data(as_text=True)[:200]))
        self.assertTrue(c.get('/salud').json['correcto'])

    def test_csrf_y_venta_web_y_doble_envio(self):
        c=app.test_client()
        respuesta=c.get('/ventas')
        html=respuesta.get_data(as_text=True)
        import re
        csrf=re.search(r'name="_csrf" value="([^"]+)"',html).group(1)
        nonce=re.search(r'name="nonce" value="([^"]+)"',html).group(1)
        antes=self.consulta('SELECT COUNT(*) FROM venta')[0][0]
        self.assertEqual(c.post('/ventas',data={'nonce':nonce,'id_producto':'1','cantidad':'1'}).status_code,400)
        datos={'_csrf':csrf,'nonce':nonce,'id_producto':'1','cantidad':'1','medio_pago':'EFECTIVO'}
        self.assertEqual(c.post('/ventas',data=datos).status_code,303)
        self.assertEqual(self.consulta('SELECT COUNT(*) FROM venta'),[(antes+1,)])
        self.assertEqual(c.post('/ventas',data=datos).status_code,303)
        self.assertEqual(self.consulta('SELECT COUNT(*) FROM venta'),[(antes+1,)])

    def test_esquema_ajeno_es_rechazado_sin_migrar(self):
        otra=Path(self.carpeta.name)/'otra.db'
        con=sqlite3.connect(otra)
        try:
            con.execute('CREATE TABLE prueba(a INTEGER)')
            con.commit()
        finally: con.close()
        os.environ['SIG_DB_PATH']=str(otra)
        with self.assertRaises(EsquemaIncompatible):conectar(True)
        con=sqlite3.connect(otra)
        try:
            self.assertEqual(con.execute('SELECT name FROM sqlite_master WHERE type="table"').fetchall(),[('prueba',)])
        finally: con.close()

if __name__=='__main__':unittest.main()
