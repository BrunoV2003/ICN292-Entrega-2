"""Pruebas sin dependencias web. Todas las escrituras se hacen en copias temporales."""
from pathlib import Path
from contextlib import closing
import hashlib
import os
import shutil
import sqlite3
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import db
from scripts.probar_flujo_operativo import prueba
from scripts.probar_restauracion import probar

DATOS_PRUEBA = Path(__file__).resolve().parent / 'datos' / 'minimarket_prueba.db'


class HerramientasLocales(unittest.TestCase):
    def setUp(self):
        # La base distribuida esta vacia; estas pruebas usan una copia de los datos sinteticos.
        self.tmp = tempfile.TemporaryDirectory(prefix='sig_herramientas_')
        self.addCleanup(self.tmp.cleanup)
        copia = Path(self.tmp.name) / 'minimarket.db'
        shutil.copyfile(DATOS_PRUEBA, copia)
        previo = os.environ.get('SIG_DB_PATH')
        os.environ['SIG_DB_PATH'] = str(copia)
        self.addCleanup(lambda: os.environ.pop('SIG_DB_PATH', None) if previo is None
                        else os.environ.__setitem__('SIG_DB_PATH', previo))

    def test_flujo_end_to_end_en_copia(self):
        cambios=prueba()
        self.assertTrue(all(x.endswith('OK') for x in cambios), cambios)
        self.assertEqual(len(cambios),8)

    def test_respaldo_restaurable_en_copia(self):
        with tempfile.TemporaryDirectory(prefix='sig_test_backup_') as temporal:
            respaldo=Path(temporal)/'respaldo.db'
            with db.lectura() as origen, closing(sqlite3.connect(respaldo)) as salida:
                origen.backup(salida)
            antes=hashlib.sha256(respaldo.read_bytes()).hexdigest()
            resultado=probar(respaldo)
            self.assertEqual(set(resultado),db.TABLAS)
            self.assertEqual(antes,hashlib.sha256(respaldo.read_bytes()).hexdigest())

    def test_no_acepta_bd_operativa_como_respaldo(self):
        with self.assertRaises(ValueError):
            probar(db.ruta_bd())

    def test_foreign_keys_y_objetos(self):
        with db.lectura() as con:
            self.assertEqual(con.execute('PRAGMA foreign_keys').fetchone()[0],1)
            self.assertEqual(con.execute('PRAGMA query_only').fetchone()[0],1)
            self.assertEqual(con.execute('PRAGMA quick_check').fetchone()[0],'ok')
            self.assertEqual(con.execute('PRAGMA foreign_key_check').fetchall(),[])
            self.assertEqual(len(db.TABLAS),9)
            self.assertEqual(len(db.VISTAS),5)


if __name__=='__main__':
    unittest.main()
