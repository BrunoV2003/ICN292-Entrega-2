"""Regresiones del candado de respaldos en Windows, también simulables en Linux.

msvcrt.locking opera en el desplazamiento actual del archivo; se comprueba
que ambos desplazamientos sean iguales y que el archivo no crezca con el tiempo.
"""
import os
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import patch

import respaldo_automatico


class CandadoRespaldoWindows(unittest.TestCase):
    def test_mismo_byte_bloqueado_y_desbloqueado_en_windows(self):
        with tempfile.TemporaryDirectory() as carpeta:
            archivo = Path(carpeta) / '.candado_respaldo_semanal'
            posiciones = []

            def locking(fd, modo, longitud):
                self.assertEqual(longitud, 1)
                posicion = os.lseek(fd, 0, os.SEEK_CUR)
                if modo == 1:
                    self.assertEqual(posicion, 0)
                    posiciones.append(posicion)
                elif modo == 2:
                    self.assertTrue(posiciones)
                    self.assertEqual(posiciones.pop(), posicion)
                else:
                    self.fail(f'Modo de bloqueo inesperado: {modo}')

            simulador_msvcrt = types.SimpleNamespace(LK_LOCK=1, LK_UNLCK=2, locking=locking)
            # No se cambia os.name de todo Python (que interferiría con pathlib).
            os_simulado = types.SimpleNamespace(name='nt', SEEK_END=os.SEEK_END)
            with patch.object(respaldo_automatico, 'os', os_simulado), \
                    patch.dict(sys.modules, {'msvcrt': simulador_msvcrt}):
                for _ in range(5):
                    with respaldo_automatico._candado(archivo):
                        self.assertEqual(archivo.stat().st_size, 1)
            self.assertEqual(posiciones, [])
            self.assertEqual(archivo.stat().st_size, 1)

    def test_desbloquea_si_falla_la_tarea(self):
        with tempfile.TemporaryDirectory() as carpeta:
            archivo = Path(carpeta) / '.candado_respaldo_semanal'
            with self.assertRaisesRegex(ValueError, 'fallo previsto'):
                with respaldo_automatico._candado(archivo):
                    raise ValueError('fallo previsto')
            with respaldo_automatico._candado(archivo):
                pass
