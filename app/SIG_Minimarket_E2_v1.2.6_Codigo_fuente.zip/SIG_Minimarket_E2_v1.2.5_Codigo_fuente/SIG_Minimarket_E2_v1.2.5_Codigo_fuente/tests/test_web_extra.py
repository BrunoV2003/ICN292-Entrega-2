"""Ensayos de escritura web y verificación de reportes con SQLite temporal."""
from pathlib import Path
from contextlib import closing
import os
import re
import shutil
import sqlite3
import tempfile
import unittest
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from app import app

class NavegadorLocal(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.db=Path(self.tmp.name)/'ensayo.db'
        shutil.copy2(Path(__file__).resolve().parent/'datos'/'minimarket_prueba.db',self.db)
        self.prev=os.environ.get('SIG_DB_PATH')
        os.environ['SIG_DB_PATH']=str(self.db)
        self.cliente=app.test_client()

    def tearDown(self):
        if self.prev is None:os.environ.pop('SIG_DB_PATH',None)
        else:os.environ['SIG_DB_PATH']=self.prev
        self.tmp.cleanup()

    def get_csrf(self,ruta):
        html=self.cliente.get(ruta).get_data(as_text=True)
        return re.search(r'name="_csrf" value="([^"]+)"',html).group(1)

    def contar(self,tabla):
        with closing(sqlite3.connect(self.db)) as con:
            return con.execute(f'SELECT COUNT(*) FROM {tabla}').fetchone()[0]

    def test_creacion_web_producto_y_proveedor(self):
        csrf=self.get_csrf('/proveedores/nuevo')
        r=self.cliente.post('/proveedores/nuevo',data={'_csrf':csrf,'nombre':'Test nuevo','plazo_entrega_dias':'2','activo':'1'})
        self.assertEqual(r.status_code,303)
        csrf=self.get_csrf('/productos/nuevo')
        r=self.cliente.post('/productos/nuevo',data={'_csrf':csrf,'codigo_interno':'INT-TESTWEB','nombre':'Producto web','precio_venta':'990','stock_minimo':'3','activo':'1'})
        self.assertEqual(r.status_code,303)
        self.assertIn('Producto web',self.cliente.get('/productos').get_data(as_text=True))

    def test_web_entrada_y_ajuste(self):
        csrf=self.get_csrf('/entradas/nueva'); antes=self.contar('entrada_stock')
        r=self.cliente.post('/entradas/nueva',data={'_csrf':csrf,'id_producto':'1','id_proveedor':'1','tipo_entrada':'RECEPCION','cantidad':'3','costo_unitario':'380,25'})
        self.assertEqual(r.status_code,303)
        self.assertEqual(self.contar('entrada_stock'),antes+1)
        csrf=self.get_csrf('/inventario/ajustes');antes=self.contar('ajuste_inventario')
        r=self.cliente.post('/inventario/ajustes',data={'_csrf':csrf,'id_producto':'1','tipo_ajuste':'MERMA','cantidad_delta':'-1','motivo':'Daño en el envase'})
        self.assertEqual(r.status_code,303)
        self.assertEqual(self.contar('ajuste_inventario'),antes+1)

    def test_web_conteo_no_muta_producto(self):
        with closing(sqlite3.connect(self.db)) as con:
            stock=con.execute('SELECT stock_actual FROM producto WHERE id_producto=1').fetchone()[0]
        csrf=self.get_csrf('/inventario/conteos')
        r=self.cliente.post('/inventario/conteos',data={'_csrf':csrf,'id_producto':'1','cantidad_fisica':str(stock-1),'observacion':'Conteo de prueba'})
        self.assertEqual(r.status_code,303)
        with closing(sqlite3.connect(self.db)) as con:
            self.assertEqual(con.execute('SELECT stock_actual FROM producto WHERE id_producto=1').fetchone()[0],stock)

    def test_web_pedido_y_recepcion_vinculada(self):
        with closing(sqlite3.connect(self.db)) as con: hoy=con.execute("SELECT date('now')").fetchone()[0]
        csrf=self.get_csrf('/pedidos/nuevo')
        r=self.cliente.post('/pedidos/nuevo',data={'_csrf':csrf,'id_proveedor':'1','fecha_entrega_estimada':hoy,'id_producto':['1','2'],'cantidad':['4','5'],'costo_estimado':['400','700']})
        self.assertEqual(r.status_code,303)
        pedido=int(r.headers['Location'].split('/')[-1])
        with closing(sqlite3.connect(self.db)) as con:
            linea=con.execute('SELECT id_detalle_pedido FROM detalle_pedido WHERE id_pedido=? AND id_producto=1',(pedido,)).fetchone()[0]
        csrf=self.get_csrf('/entradas/nueva')
        r=self.cliente.post('/entradas/nueva',data={'_csrf':csrf,'tipo_entrada':'RECEPCION','id_detalle_pedido':str(linea),'cantidad':'2','costo_unitario':'350'})
        self.assertEqual(r.status_code,303)
        with closing(sqlite3.connect(self.db)) as con:
            self.assertEqual(con.execute('SELECT estado_recepcion FROM v_estado_pedidos WHERE id_pedido=?',(pedido,)).fetchone()[0],'PARCIAL')

    def test_operaciones_preservan_estructura_con_tres_tablas_caja(self):
        csrf=self.get_csrf('/ventas')
        html=self.cliente.get('/ventas').get_data(as_text=True)
        nonce=re.search(r'name="nonce" value="([^"]+)"',html).group(1)
        r=self.cliente.post('/ventas',data={'_csrf':csrf,'nonce':nonce,'id_producto':'1','cantidad':'1','medio_pago':'EFECTIVO'})
        self.assertEqual(r.status_code,303)
        with closing(sqlite3.connect(self.db)) as con:
            self.assertEqual(con.execute("SELECT count(*) FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").fetchone()[0],15)
            self.assertEqual(con.execute("SELECT count(*) FROM sqlite_master WHERE type='view'").fetchone()[0],5)
            self.assertEqual(con.execute('PRAGMA quick_check').fetchone()[0],'ok')
            self.assertEqual(con.execute('PRAGMA foreign_key_check').fetchall(),[])

    def test_pdf_o_documento_tributario_no_se_promete(self):
        html=self.cliente.get('/ventas/1').get_data(as_text=True)
        self.assertIn('Documento interno, no boleta tributaria.',html)

if __name__=='__main__':unittest.main()
