"""Regresiones de pagos, conciliación, consulta segura y respaldo 60 días."""
from contextlib import closing
from datetime import datetime
from io import BytesIO
import os
from pathlib import Path
import shutil
import sqlite3
import tempfile
import unittest
from unittest.mock import patch

from werkzeug.datastructures import MultiDict
import db
from caja import conciliar, guardar_arqueo, resumen_pagos
from operaciones import guardar_venta, ErrorOperacion, cerrar_jornada
from reloj import hoy_chile, CHILE
from respaldo_automatico import ultima_cita, ejecutar_pendiente
import gemini_sig
from app import app

class CajaV122(unittest.TestCase):
    def setUp(self):
        self.dir=tempfile.TemporaryDirectory(prefix='sig_caja_v122_')
        self.addCleanup(self.dir.cleanup)
        self.previous={k:os.environ.get(k) for k in ('SIG_DB_PATH','SIG_DATA_DIR','SIG_GEMINI_API_KEY')}
        self.addCleanup(self._restore)
        ruta=Path(self.dir.name)/'minimarket.db'
        shutil.copyfile(Path(__file__).resolve().parent/'datos'/'minimarket_prueba.db',ruta)
        os.environ['SIG_DB_PATH']=str(ruta)
        os.environ['SIG_DATA_DIR']=str(Path(self.dir.name)/'datos')
        os.environ.pop('SIG_GEMINI_API_KEY',None)
        db.migrar_caja()
        self.ruta=ruta

    def _restore(self):
        for k,v in self.previous.items():
            if v is None:os.environ.pop(k,None)
            else:os.environ[k]=v

    def _venta(self, **kwargs):
        data=MultiDict([('id_producto','1'),('cantidad','1'),*kwargs.items()])
        return guardar_venta(data)

    def test_pago_transbank_atraves_de_misma_transaccion(self):
        venta=self._venta(medio_pago='TRANSBANK',transbank_confirmado='1',referencia_transbank='R22')
        with db.lectura() as con:
            pagos=con.execute('SELECT medio,monto_clp,confirmado FROM sig_pago_venta WHERE id_venta=?',(venta,)).fetchall()
        self.assertEqual([tuple(x) for x in pagos],[('TRANSBANK',700,1)])

    def test_pago_mixto_erroneo_revierte_venta_y_stock(self):
        with db.lectura() as con:
            antes=con.execute('SELECT COUNT(*) FROM venta').fetchone()[0]
            stock=con.execute('SELECT stock_actual FROM producto WHERE id_producto=1').fetchone()[0]
        with self.assertRaises(ErrorOperacion):
            self._venta(medio_pago='MIXTO',monto_efectivo='50',monto_transbank='50',transbank_confirmado='1')
        with db.lectura() as con:
            self.assertEqual(con.execute('SELECT COUNT(*) FROM venta').fetchone()[0],antes)
            self.assertEqual(con.execute('SELECT stock_actual FROM producto WHERE id_producto=1').fetchone()[0],stock)

    def test_reporte_total_y_operacion(self):
        self._venta(medio_pago='TRANSBANK',transbank_confirmado='1',referencia_transbank='REF-10')
        dato={'fecha_reporte':hoy_chile(),'nivel_detalle':'DETALLE','total_reporte_clp':700,
              'operaciones':[{'referencia':'REF-10','monto_clp':700}]}
        r=conciliar(dato,guardar=True)
        self.assertEqual(r['estado'],'OPERACIONES_VERIFICADAS')
        dato['nivel_detalle']='RESUMEN';dato['operaciones']=[]
        self.assertEqual(conciliar(dato)['estado'],'TOTALES_COINCIDEN')
        self.assertEqual(conciliar(dato)['individuales'],'NO_VERIFICABLES')
        dato['total_reporte_clp']=699
        self.assertEqual(conciliar(dato)['estado'],'DIFERENCIA')

    def test_arqueo_y_cierre_excepcional(self):
        self._venta(medio_pago='EFECTIVO')
        self.assertEqual(guardar_arqueo({'fondo_inicial_clp':'1000','retiros_clp':'0',
              'contado_clp':'1700'}),0)
        _,nuevo=cerrar_jornada(validar_caja=True)
        self.assertTrue(nuevo)

    def test_una_fecha_diferente_no_se_concilia(self):
        self._venta(medio_pago='TRANSBANK',transbank_confirmado='1')
        r=conciliar({'fecha_reporte':'2026-01-01','nivel_detalle':'RESUMEN','total_reporte_clp':700})
        self.assertEqual(r['estado'],'INFORMACION_INSUFICIENTE')

    def test_ultimo_domingo_y_respaldo_no_duplicado(self):
        self.assertEqual(ultima_cita(datetime(2026,11,8,3,0,tzinfo=CHILE)),'2026-11-01')
        self.assertEqual(ultima_cita(datetime(2026,11,8,4,1,tzinfo=CHILE)),'2026-11-08')
        uno,ruta=ejecutar_pendiente(datetime(2026,11,11,12,tzinfo=CHILE))
        dos,ruta2=ejecutar_pendiente(datetime(2026,11,12,12,tzinfo=CHILE))
        self.assertEqual((uno,dos),('CREADO','YA_REALIZADO'))
        self.assertEqual(ruta,ruta2)

    def test_asistente_ejecuta_sql_permitido(self):
        self._venta(medio_pago='TRANSBANK',transbank_confirmado='1')
        with patch('gemini_sig._pedir',return_value={'funcion':'ventas_por_medio','medio':'TRANSBANK'}):
            respuesta=gemini_sig.preguntar('¿Cuánto vendí por Transbank hoy?')
        self.assertEqual(respuesta['filas'][0][1],700)
        with patch('gemini_sig._pedir',return_value={'funcion':'DROP TABLE venta'}):
            with self.assertRaises(ErrorOperacion):gemini_sig.preguntar('Borra todas las ventas')
        with db.lectura() as con:self.assertTrue(con.execute('SELECT COUNT(*) FROM venta').fetchone()[0]>0)

    def test_formulario_cierre_y_gemini_sin_clave(self):
        with app.test_client() as c:
            self.assertIn('Medio de pago',c.get('/ventas').get_data(as_text=True))
            self.assertIn('Arqueo manual',c.get('/ventas/cierre').get_data(as_text=True))
            self.assertIn('SIG_GEMINI_API_KEY',c.get('/consultas').get_data(as_text=True))

    def test_subida_y_revision_con_gemini_simulado(self):
        with patch.dict(os.environ,{'SIG_GEMINI_API_KEY':'CLAVE_SOLO_TEST'}), app.test_client() as c:
            with c.session_transaction() as ses:ses['_csrf']='TEST-123'
            with patch('gemini_sig.extraer_reporte',return_value={'fecha_reporte':hoy_chile(),
                    'nivel_detalle':'RESUMEN','total_reporte_clp':0,'operaciones':[]}):
                r=c.post('/ventas/cierre/leer-transbank',data={'_csrf':'TEST-123',
                    'reporte':(BytesIO(b'\xff\xd8FOTO_SIMULADA'),'reporte.jpg','image/jpeg')},
                    content_type='multipart/form-data')
            self.assertEqual(r.status_code,200)
            self.assertIn('Revisar reporte Transbank',r.get_data(as_text=True))
