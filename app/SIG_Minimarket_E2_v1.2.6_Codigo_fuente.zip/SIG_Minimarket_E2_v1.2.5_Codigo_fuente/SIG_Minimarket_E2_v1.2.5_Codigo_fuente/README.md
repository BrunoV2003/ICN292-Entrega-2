# SIG Minimarket E2 v1.2.4 — código para construir en Windows

Este ZIP **contiene el código fuente, no el .exe**. Es independiente del paquete ejecutable v1.2.1 ya existente.

En Windows, con Python 3.10+ instalado solo para construir, ejecutar `CONSTRUIR_EXE_WINDOWS.bat`. El compilador corre la batería `pytest`, construye el EXE con PyInstaller y realiza una prueba HTTP/SQLite en datos temporales. Si termina bien crea `dist/SIG_Minimarket_E2_v1.2.4.zip`. El usuario final no necesita Python.

La carpeta final contiene un único archivo `.exe` visible, `_internal` obligatorio y los documentos de licencia/uso. No requiere iniciar scripts auxiliares, n8n ni cambiar SQLite a otra tecnología.

Los cambios están detallados en el informe externo `SIG_Minimarket_E2_v1.2.4_CAMBIOS_Y_PRUEBAS.md` entregado aparte. Las pruebas con Gemini real y lector físico requieren el equipo Windows definitivo.

Variables de entorno: `SIG_DB_PATH` permite seleccionar la base real; `SIG_DATA_DIR` el directorio de datos y respaldos; `SIG_GEMINI_API_KEY` habilita Gemini; `SIG_ADMIN_PIN` controla reapertura de día. Nunca almacenar secretos en el repositorio ni en un ZIP de distribución.

## Nueva operación de Ventas v1.2.4

El flujo es **Iniciar venta → escanear o buscar → revisar subtotal y total → Cobrar → confirmar pago**. El escáner se enfoca al iniciar y tras cada lectura (F2 permite recuperarlo). La pantalla de cobro conserva efectivo, Transbank y mixto. Un carrito cancelado no genera ventas ni folios. El folio mostrado durante el registro es provisional; el definitivo se confirma en SQLite al guardar.

El cierre de caja, Gemini, los respaldos de 60 días y el resto del SIG se conservan de la v1.2.2. No se añaden dependencias nuevas.

## Correcciones de v1.2.4

- El candado del respaldo automático en Windows ahora bloquea y libera el **mismo byte** del archivo de control; el archivo de candado no crece en cada respaldo.
- La prueba de la pantalla de ventas comprueba los controles reales del nuevo POS en lugar de exigir un texto eliminado en el rediseño.
- Se agrega una regresión del bloqueo compatible con la ejecución de pruebas fuera de Windows. No se cambian las reglas de stock, los folios ni la base de datos.

**Primera compilación:** descomprime esta versión en una carpeta nueva y ejecuta `CONSTRUIR_EXE_WINDOWS.bat`. No mezcles scripts ni la `.venv_build` con la v1.2.3. En Windows deben pasar todas las pruebas antes de que se genere el ZIP final.
