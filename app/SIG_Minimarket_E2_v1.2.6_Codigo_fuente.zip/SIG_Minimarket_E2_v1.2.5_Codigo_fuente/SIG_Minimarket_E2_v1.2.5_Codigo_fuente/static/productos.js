'use strict';
function iniciarProducto(idActual){
  const form=document.getElementById('form-producto');
  const campo=document.getElementById('campo-barras');
  const detalle=document.getElementById('detalle-producto');
  const input=document.getElementById('codigo-barras-producto');
  const estado=document.getElementById('estado-barras');
  function actualizar(){
    const modo=form.querySelector('input[name="modo_codigo"]:checked')?.value;
    campo.hidden=modo!=='con';detalle.hidden=!modo;
    input.required=modo==='con';input.disabled=modo!=='con';
    if(modo==='sin')input.value='';
    if(modo==='con')input.focus();
    else if(modo==='sin')form.querySelector('[name="nombre"]').focus();
  }
  form.querySelectorAll('input[name="modo_codigo"]').forEach(e=>e.addEventListener('change',actualizar));
  input.addEventListener('keydown',e=>{
    if(e.key==='Enter'){e.preventDefault();comprobar();}
  });
  async function comprobar(){
    if(!input.value.trim()) return;
    estado.textContent='Verificando código…';
    try{
      const r=await fetch('/api/productos/codigo?codigo='+encodeURIComponent(input.value.trim()));
      if(r.ok){
        const p=await r.json();
        estado.textContent=p.id_producto===idActual?'Código actual de este producto.':'Ese código ya pertenece a: '+p.nombre+'. No puedes duplicarlo.';
      }else if(r.status===404){estado.textContent='Código disponible. Completa los demás datos.';}
      else{estado.textContent='No fue posible verificar el código. Se revisará al guardar.';}
    }catch(e){estado.textContent='Sin consulta en línea. El servidor validará al guardar.';}
  }
  input.addEventListener('change',comprobar);
  actualizar();
}
