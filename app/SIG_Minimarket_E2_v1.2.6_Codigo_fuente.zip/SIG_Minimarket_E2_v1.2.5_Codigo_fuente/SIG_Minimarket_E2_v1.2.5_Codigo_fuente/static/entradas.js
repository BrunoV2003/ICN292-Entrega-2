'use strict';
function iniciarEntradaNueva(preproducto,prelinea){
  const form=document.getElementById('form-entrada'), lector=document.getElementById('lector-entrada');
  const seccion=document.getElementById('entrada-etapa2'), id=document.getElementById('entrada-id-producto');
  const listado=document.getElementById('seleccionar-entrada'),buscar=document.getElementById('buscar-entrada');
  const identificado=document.getElementById('producto-identificado'),aviso=document.getElementById('aviso-identificacion');
  const linea=document.getElementById('linea-pedido'),tipo=document.getElementById('tipo'),cantidad=document.getElementById('cantidad'),proveedor=document.getElementById('campo-proveedor');
  function refrescarPedido(){
    for(const op of linea.options){if(op.value)op.hidden=op.dataset.producto!==id.value;}
    if(linea.value && linea.selectedOptions[0].dataset.producto!==id.value)linea.value='';
    const vinculado=Boolean(linea.value);
    proveedor.hidden=vinculado;tipo.querySelector('option[value="CARGA_INICIAL"]').disabled=vinculado;
    const avisoP=document.getElementById('aviso-pendiente');
    if(vinculado){
      tipo.value='RECEPCION';
      cantidad.max=linea.selectedOptions[0].dataset.restante;
      avisoP.textContent='Pedido asociado: máximo '+cantidad.max+' unidades pendientes. Stock y CPP cambian por triggers SQLite.';
    }else{cantidad.removeAttribute('max');avisoP.textContent='Entrada sin pedido. Stock y CPP cambian por triggers SQLite.';}
  }
  function establecer(p){
    if(!p || !p.id_producto){aviso.textContent='Selecciona primero un producto válido.';return;}
    id.value=String(p.id_producto);seccion.hidden=false;
    identificado.hidden=false;identificado.textContent='Producto identificado: '+p.nombre+' · Stock actual: '+p.stock_actual;
    aviso.textContent='Producto identificado. Completa ahora los datos de recepción.';
    refrescarPedido();cantidad.focus();
  }
  async function leer(){
    const codigo=lector.value.trim();lector.value='';if(!codigo)return;
    try{
      const r=await fetch('/api/productos/codigo?codigo='+encodeURIComponent(codigo));const p=await r.json();
      if(!r.ok || p.activo!==1){aviso.textContent=p.error||'Producto inactivo o no registrado.';return;}
      establecer(p);
    }catch(e){aviso.textContent='No fue posible consultar Flask.';}
  }
  let tScan;
  lector.addEventListener('keydown',e=>{
    if((e.key==='Enter'||e.key==='Tab') && lector.value.trim()){
      e.preventDefault();clearTimeout(tScan);leer();
    }
  });
  lector.addEventListener('input',()=>{clearTimeout(tScan);if(lector.value.trim())tScan=setTimeout(leer,500);});
  const opciones=[...listado.options].filter(o=>o.value).map(o=>({id_producto:Number(o.value),nombre:o.dataset.nombre,stock_actual:Number(o.dataset.stock),codigo_barras:o.dataset.barras}));
  function filtrar(){
    const q=buscar.value.toLocaleLowerCase('es-CL').trim(),actual=listado.value;
    listado.replaceChildren();listado.add(new Option('Selecciona un producto',''));
    opciones.filter(p=>p.nombre.toLocaleLowerCase('es-CL').includes(q)).forEach(p=>listado.add(new Option(p.nombre+' · stock '+p.stock_actual,String(p.id_producto))));
    if([...listado.options].some(o=>o.value===actual))listado.value=actual;
  }
  buscar.addEventListener('input',filtrar);
  listado.addEventListener('change',()=>{
    const p=opciones.find(x=>String(x.id_producto)===listado.value);if(p)establecer(p);
    else{seccion.hidden=true;identificado.hidden=true;id.value='';}
  });
  form.querySelectorAll('input[name="identificacion"]').forEach(r=>r.addEventListener('change',()=>{
    const manual=form.querySelector('[name="identificacion"]:checked').value==='manual';
    document.getElementById('entrada-buscador').hidden=!manual;
    document.getElementById('entrada-lector').hidden=manual;
    id.value='';identificado.hidden=true;seccion.hidden=true;linea.value='';
    (manual?buscar:lector).focus();
  }));
  linea.addEventListener('change',refrescarPedido);
  form.addEventListener('submit',e=>{
    if(!id.value){e.preventDefault();aviso.textContent='Identifica un producto antes de guardar.';return;}
    if(linea.value && linea.selectedOptions[0].dataset.producto!==id.value){e.preventDefault();aviso.textContent='El pedido no coincide con el producto elegido.';}
  });
  filtrar();
  const elegido=prelinea?linea.querySelector('option[value="'+CSS.escape(String(prelinea))+'"]'):null;
  const identificador=preproducto||(elegido?elegido.dataset.producto:'');
  if(identificador){
    form.querySelector('[name="identificacion"][value="manual"]').checked=true;
    document.getElementById('entrada-buscador').hidden=false;
    document.getElementById('entrada-lector').hidden=true;
    const p=opciones.find(x=>String(x.id_producto)===String(identificador));
    if(p){listado.value=String(p.id_producto);establecer(p);if(elegido){linea.value=String(prelinea);refrescarPedido();}}
  }else lector.focus();
}
