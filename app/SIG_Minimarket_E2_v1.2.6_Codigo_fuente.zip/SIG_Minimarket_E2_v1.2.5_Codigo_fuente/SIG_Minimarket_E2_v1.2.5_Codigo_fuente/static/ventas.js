'use strict';
/* Terminal POS: inicio explícito, carrito por escaneo y cobro en un paso separado.
   Los folios y cambios de stock solo los confirma el servidor en la transacción SQL. */
function iniciarVenta(sinCodigo){
  const form=document.getElementById('form-venta');
  if(!form)return;
  const bienvenida=document.getElementById('venta-bienvenida');
  const curso=document.getElementById('venta-curso');
  const panelResumen=document.getElementById('pos-resumen');
  const panelPago=document.getElementById('pos-pago');
  const botonIniciar=document.getElementById('comenzar-venta');
  const botonCobrar=document.getElementById('ir-a-cobro');
  const escaner=document.getElementById('lector-venta');
  const carrito=document.getElementById('carrito');
  const estado=document.getElementById('aviso-venta');
  const select=document.getElementById('producto-manual');
  const buscar=document.getElementById('buscar-manual');
  const medio=document.getElementById('medio-pago');
  const datosTB=document.getElementById('datos-transbank');
  const mixto=document.getElementById('mixto-pago');
  const dinero=new Intl.NumberFormat('es-CL',{style:'currency',currency:'CLP',maximumFractionDigits:0});
  const items=new Map();
  let totalActual=0;
  let etapa='inicio';
  let enviando=false;
  let tiempoEscaneo;
  let numeroOperacion=0;
  let lecturasPendientes=0;

  function usuarioEditando(){
    const a=document.activeElement;
    return !!(a && a!==escaner && (a.matches('input, textarea, select, button') || a.isContentEditable));
  }
  function enfocarLector(){
    if(etapa==='carrito' && document.getElementById('venta-manual').hidden){
      requestAnimationFrame(()=>escaner.focus({preventScroll:true}));
    }
  }
  function mostrarEtapa(nueva){
    etapa=nueva;
    bienvenida.hidden=nueva!=='inicio';
    curso.hidden=nueva==='inicio';
    panelResumen.hidden=nueva!=='carrito';
    panelPago.hidden=nueva!=='pago';
    if(nueva==='carrito'){
      escaner.disabled=false;
      enfocarLector();
    }else if(nueva==='pago'){
      escaner.disabled=true;
      medio.focus({preventScroll:true});
    }else{
      escaner.disabled=true;
      botonIniciar.focus({preventScroll:true});
    }
  }
  botonIniciar.addEventListener('click',()=>{
    numeroOperacion++;
    mostrarEtapa('carrito');
    estado.textContent='Venta iniciada. Escanea el primer producto.';
    curso.scrollIntoView({behavior:'auto',block:'start'});
  });
  document.getElementById('cancelar-venta').addEventListener('click',()=>{
    if(items.size && !window.confirm('¿Cancelar esta venta? Se perderán los productos del carrito.'))return;
    numeroOperacion++;
    clearTimeout(tiempoEscaneo);
    items.clear();
    form.reset();
    actualizarMedio();
    escaner.value='';
    buscar.value='';
    document.getElementById('venta-manual').hidden=true;
    filtrar();
    actualizar();
    mostrarEtapa('inicio');
    bienvenida.scrollIntoView({behavior:'auto',block:'start'});
  });
  document.getElementById('volver-productos').addEventListener('click',()=>mostrarEtapa('carrito'));
  botonCobrar.addEventListener('click',()=>{
    if(!items.size||lecturasPendientes)return;
    document.getElementById('venta-manual').hidden=true;
    mostrarEtapa('pago');
  });

  function actualizarMedio(){
    const usaTB=medio.value==='TRANSBANK'||medio.value==='MIXTO';
    datosTB.hidden=!usaTB;
    mixto.hidden=medio.value!=='MIXTO';
    document.getElementById('transbank-confirmado').required=usaTB;
    document.getElementById('monto-efectivo').required=medio.value==='MIXTO';
    document.getElementById('monto-transbank').required=medio.value==='MIXTO';
  }
  medio.addEventListener('change',actualizarMedio);
  actualizarMedio();

  function actualizar(){
    carrito.replaceChildren();
    let total=0,unidades=0;
    if(!items.size){
      const fila=carrito.insertRow();
      fila.innerHTML='<td colspan="5" class="empty">La venta está vacía. Escanea el primer producto.</td>';
    }
    items.forEach((p,id)=>{
      const tr=carrito.insertRow();
      const nombre=tr.insertCell();nombre.textContent=p.nombre+' (disponible: '+p.stock_actual+')';
      const precio=tr.insertCell();precio.className='num';precio.textContent=dinero.format(p.precio_venta);
      const cant=tr.insertCell();cant.className='num';
      const input=document.createElement('input');
      input.type='number';input.min='1';input.max=String(p.stock_actual);
      input.step='1';input.value=String(p.cantidad);input.className='inp';
      input.setAttribute('aria-label','Cantidad de '+p.nombre);
      input.name='cantidad';input.required=true;
      input.addEventListener('change',()=>{
        const n=Number(input.value);
        if(!Number.isInteger(n)||n<1||n>p.stock_actual){
          estado.textContent='Cantidad inválida o superior al stock disponible.';
          input.value=String(p.cantidad);return;
        }
        p.cantidad=n;actualizar();
      });
      cant.appendChild(input);
      const oculto=document.createElement('input');oculto.type='hidden';oculto.name='id_producto';oculto.value=id;cant.appendChild(oculto);
      const origen=document.createElement('input');origen.type='hidden';origen.name='modo_identificacion';origen.value=p.origen||'barras';cant.appendChild(origen);
      const subt=tr.insertCell();subt.className='num';subt.textContent=dinero.format(p.cantidad*p.precio_venta);
      const acc=tr.insertCell();
      const btn=document.createElement('button');btn.type='button';btn.className='btn btn-gray btn-small';btn.textContent='Quitar';
      btn.addEventListener('click',()=>{items.delete(id);actualizar();enfocarLector();});acc.appendChild(btn);
      total+=p.cantidad*p.precio_venta;unidades+=p.cantidad;
    });
    totalActual=total;
    document.getElementById('subtotal-venta').textContent=dinero.format(total);
    document.getElementById('total-venta').textContent=dinero.format(total);
    document.getElementById('total-cobrar').textContent=dinero.format(total);
    document.getElementById('total-pago').textContent=dinero.format(total);
    document.getElementById('cantidad-venta').textContent=String(unidades);
    document.getElementById('articulos-carrito').textContent=unidades===1?'1 artículo':unidades+' artículos';
    botonCobrar.disabled=!items.size||lecturasPendientes>0;
  }
  function agregar(p,origen='barras'){
    if(etapa!=='carrito')return;
    if(!p || (!p.activo && p.activo!==undefined)){
      estado.textContent='Producto inexistente o inactivo.';return;
    }
    const id=String(p.id_producto),actual=items.get(id);
    if(actual){
      if(actual.cantidad>=actual.stock_actual){estado.textContent='No hay más stock de '+actual.nombre+'.';return;}
      actual.cantidad++;
    }else{
      if(p.stock_actual<1){estado.textContent='Sin stock disponible: '+p.nombre+'.';return;}
      items.set(id,{...p,cantidad:1,origen});
    }
    estado.textContent='Agregado: '+p.nombre;
    actualizar();
    if(!usuarioEditando())enfocarLector();
  }
  async function leer(){
    if(etapa!=='carrito')return;
    const codigo=escaner.value.trim();
    escaner.value='';
    if(!codigo)return;
    const operacionDeLectura=numeroOperacion;
    lecturasPendientes++;
    botonCobrar.disabled=true;
    try{
      const r=await fetch('/api/productos/codigo?codigo='+encodeURIComponent(codigo));
      const p=await r.json();
      if(etapa!=='carrito'||operacionDeLectura!==numeroOperacion)return;
      if(!r.ok){estado.textContent=p.error||'Código no encontrado.';return;}
      agregar(p);
    }catch(e){
      if(operacionDeLectura===numeroOperacion)estado.textContent='No se pudo consultar el producto. Revisa la conexión local con Flask.';
    }finally{
      lecturasPendientes--;
      botonCobrar.disabled=!items.size||lecturasPendientes>0;
      if(etapa==='carrito'&&operacionDeLectura===numeroOperacion&&!usuarioEditando())enfocarLector();
    }
  }
  escaner.addEventListener('keydown',ev=>{
    if((ev.key==='Enter'||ev.key==='Tab') && escaner.value.trim()){
      ev.preventDefault();clearTimeout(tiempoEscaneo);leer();
    }
  });
  escaner.addEventListener('input',()=>{
    clearTimeout(tiempoEscaneo);
    if(etapa==='carrito'&&escaner.value.trim())tiempoEscaneo=setTimeout(leer,500);
  });
  document.getElementById('mostrar-manual').addEventListener('click',()=>{
    const div=document.getElementById('venta-manual');div.hidden=!div.hidden;
    if(!div.hidden)buscar.focus();else enfocarLector();
  });
  function filtrar(){
    const q=buscar.value.toLocaleLowerCase('es-CL').trim();
    select.replaceChildren();
    select.add(new Option('Selecciona un producto',''));
    sinCodigo.filter(p=>p.nombre.toLocaleLowerCase('es-CL').includes(q)).forEach(p=>
      select.add(new Option(p.nombre+' · '+dinero.format(p.precio_venta)+' · stock '+p.stock_actual,String(p.id_producto))));
  }
  buscar.addEventListener('input',filtrar);filtrar();
  document.getElementById('agregar-manual').addEventListener('click',()=>{
    const p=sinCodigo.find(v=>String(v.id_producto)===select.value);
    if(!p){estado.textContent='Selecciona un producto sin código de barras.';return;}
    agregar(p,'manual');
    document.getElementById('venta-manual').hidden=true;
    buscar.value='';
    filtrar();
    enfocarLector();
  });
  // Escáner modo teclado: solo se redirigen teclas cuando la venta está activa
  // y la persona no está escribiendo en otro control (cantidades, búsqueda o pago).
  document.addEventListener('keydown',ev=>{
    if(etapa!=='carrito'||ev.defaultPrevented||ev.ctrlKey||ev.altKey||ev.metaKey||ev.isComposing)return;
    if(ev.key==='F2'){
      ev.preventDefault();escaner.focus({preventScroll:true});escaner.select();return;
    }
    if(usuarioEditando()||document.getElementById('venta-manual').hidden===false)return;
    if(document.activeElement===escaner)return;
    if(ev.key.length===1&&!ev.repeat){
      escaner.focus({preventScroll:true});escaner.value+=ev.key;
      escaner.dispatchEvent(new Event('input',{bubbles:true}));ev.preventDefault();
    }
  });
  window.addEventListener('focus',()=>{if(etapa==='carrito'&&!usuarioEditando())enfocarLector();});
  form.addEventListener('submit',ev=>{
    if(etapa!=='pago'||!items.size){
      ev.preventDefault();estado.textContent='Primero agrega productos y pasa al cobro.';return;
    }
    if(medio.value==='MIXTO'){
      const e=Number(document.getElementById('monto-efectivo').value);
      const t=Number(document.getElementById('monto-transbank').value);
      if(!Number.isInteger(e)||!Number.isInteger(t)||e<=0||t<=0||e+t!==totalActual){
        ev.preventDefault();
        estado.textContent='Los dos montos deben sumar exactamente el total.';
        document.getElementById('monto-efectivo').focus();return;
      }
    }
    if(enviando){ev.preventDefault();return;}
    enviando=true;
    document.getElementById('confirmar-venta').disabled=true;
  });
  actualizar();
  mostrarEtapa('inicio');
}
