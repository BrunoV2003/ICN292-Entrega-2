/* Sólo comportamiento de interfaz; precios, CPP y stock se verifican en el servidor. */
'use strict';
function iniciarLineas(modo){
  const contenedor=document.getElementById('lineas');
  const plantilla=document.getElementById('plantilla-linea');
  const agregar=document.getElementById('agregar-linea');
  const formulario=document.getElementById(modo==='venta'?'form-venta':'form-pedido');
  const dinero=new Intl.NumberFormat('es-CL',{style:'currency',currency:'CLP',maximumFractionDigits:0});
  function actualizar(){
    if(modo!=='venta') return;
    let total=0;
    contenedor.querySelectorAll('.linea').forEach(linea=>{
      const sel=linea.querySelector('select[name="id_producto"]');
      const opt=sel.selectedOptions[0];
      const cant=Number(linea.querySelector('input[name="cantidad"]').value)||0;
      const precio=Number(opt?.dataset?.precio)||0;
      const stock=opt?.dataset?.stock;
      const info=linea.querySelector('.disponible');
      if(info) info.textContent=stock===undefined?'':'Disponible: '+stock+' unidades';
      total+=cant*precio;
    });
    document.getElementById('total-venta').textContent=dinero.format(total);
  }
  function crear(){
    const item=plantilla.content.firstElementChild.cloneNode(true);
    item.querySelector('[data-quitar]').addEventListener('click',()=>{
      item.remove();
      if(!contenedor.children.length) crear();
      actualizar();
    });
    item.querySelectorAll('select,input').forEach(control=>control.addEventListener('input',actualizar));
    contenedor.appendChild(item);
    actualizar();
  }
  agregar.addEventListener('click',crear);
  formulario.addEventListener('submit',(ev)=>{
    const valores=[...contenedor.querySelectorAll('select[name="id_producto"]')].map(e=>e.value);
    if(!valores.length||valores.some(v=>!v)||new Set(valores).size!==valores.length){
      ev.preventDefault();alert('Selecciona productos distintos y completa todas las líneas.');return;
    }
    if(modo==='venta'){
      formulario.querySelector('button[type="submit"]').disabled=true;
    }
  });
  crear();
}
function iniciarEntrada(){
  const linea=document.getElementById('linea-pedido');
  const tipo=document.getElementById('tipo');
  const producto=document.getElementById('campo-producto');
  const proveedor=document.getElementById('campo-proveedor');
  const aviso=document.getElementById('aviso-pendiente');
  const cantidad=document.getElementById('cantidad');
  function refrescar(){
    const vinculado=Boolean(linea.value);
    producto.hidden=vinculado;
    proveedor.hidden=vinculado;
    tipo.querySelector('[value="CARGA_INICIAL"]').disabled=vinculado;
    if(vinculado){
      tipo.value='RECEPCION';
      const restante=Number(linea.selectedOptions[0].dataset.restante);
      cantidad.max=restante;
      aviso.textContent='Recepción vinculada a pedido. Cantidad máxima pendiente: '+restante+' unidades.';
    }else{
      cantidad.removeAttribute('max');
      aviso.textContent='Entrada sin pedido. El stock y el CPP se actualizan mediante los triggers de SQLite.';
    }
  }
  linea.addEventListener('change',refrescar);refrescar();
}
