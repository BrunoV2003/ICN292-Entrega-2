@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
echo ======================================================
echo  SIG Minimarket E2 - Construccion de EXE Windows x64
echo  Solo para CONSTRUIR. El usuario final NO necesita Python.
echo ======================================================
echo.
rem Nunca ejecutar pruebas contra SIG_DB_PATH heredada del usuario.
set "SIG_DB_PATH="
set "SIG_DATA_DIR="
if not exist "sig_windows.py" (
 echo ERROR: falta sig_windows.py
 goto error
)
if not exist ".venv_build\Scripts\python.exe" (
 py -3 -m venv .venv_build
 if errorlevel 1 goto error
)
".venv_build\Scripts\python.exe" -m pip install -r requirements.txt -r requirements_build.txt
if errorlevel 1 goto error
".venv_build\Scripts\python.exe" -m pytest -q
if errorlevel 1 goto error
".venv_build\Scripts\python.exe" -m PyInstaller --noconfirm --clean sig_windows.spec
if errorlevel 1 goto error
if not exist "dist\SIG_Minimarket_E2_v1.2.4\SIG_Minimarket_E2_v1.2.4.exe" goto error
copy /Y "LICENSE_OPENSTOCK" "dist\SIG_Minimarket_E2_v1.2.4\" >nul
copy /Y "LEEME_EJECUTABLE_WINDOWS.txt" "dist\SIG_Minimarket_E2_v1.2.4\" >nul
set "SIG_DATA_DIR=%TEMP%\SIG_MINIMARKET_COMPROBACION_%RANDOM%_%RANDOM%"
set "SIG_DB_PATH="
set "SIG_NO_TASK_SETUP=1"
"dist\SIG_Minimarket_E2_v1.2.4\SIG_Minimarket_E2_v1.2.4.exe" --verificar
if errorlevel 1 goto error
"dist\SIG_Minimarket_E2_v1.2.4\SIG_Minimarket_E2_v1.2.4.exe" --respaldar
if errorlevel 1 goto error
"dist\SIG_Minimarket_E2_v1.2.4\SIG_Minimarket_E2_v1.2.4.exe" --probar-restauracion
if errorlevel 1 goto error
set "SIG_DATA_DIR="
powershell -NoProfile -ExecutionPolicy Bypass -File "PRUEBA_EJECUTABLE_WINDOWS.ps1"
if errorlevel 1 goto error
powershell -NoProfile -Command "Compress-Archive -Path 'dist\SIG_Minimarket_E2_v1.2.4' -DestinationPath 'dist\SIG_Minimarket_E2_v1.2.4.zip' -Force"
if errorlevel 1 goto error
echo.
echo LISTO: dist\SIG_Minimarket_E2_v1.2.4.zip
echo Entregue ese ZIP completo, NO el EXE aislado.
pause
exit /b 0
:error
echo.
echo ERROR: no se creo un paquete validado. Revise lo mostrado arriba.
pause
exit /b 1
