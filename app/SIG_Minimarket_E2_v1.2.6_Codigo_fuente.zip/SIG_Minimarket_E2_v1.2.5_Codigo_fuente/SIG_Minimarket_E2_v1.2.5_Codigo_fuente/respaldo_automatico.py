"""Respaldo semanal recuperable, ejecutable desde el propio SIG o Programador de tareas.

No necesita que Windows esté encendido el domingo a las 04:00; la primera
comprobación posterior crea un respaldo si quedó pendiente. No duplica semanas.
"""
from contextlib import contextmanager
from datetime import datetime, timedelta, time
import json
import os
from pathlib import Path
import subprocess
import sys
from threading import Thread, Event

from reloj import CHILE, ahora_chile
import db
from scripts.respaldo_semanal import respaldar


@contextmanager
def _candado(archivo):
    # Bloqueo a nivel sistema operativo entre procesos del EXE y tareas Windows.
    with archivo.open('a+b') as f:
        # "a+b" siempre ESCRIBE al final, aunque se haya hecho seek(0).
        # Se crea un único byte si es un archivo nuevo, sin agrandarlo en
        # cada ejecución. msvcrt.locking bloquea desde la posición ACTUAL:
        # para desbloquear hay que volver exactamente a esa misma posición.
        f.seek(0, os.SEEK_END)
        if f.tell() == 0:
            f.write(b'0')
            f.flush()
        f.seek(0)
        if os.name == 'nt':
            import msvcrt
            msvcrt.locking(f.fileno(), msvcrt.LK_LOCK, 1)
        else:
            import fcntl
            fcntl.flock(f.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            # No confiar en dónde quedó el puntero tras ejecutar respaldar().
            f.seek(0)
            if os.name == 'nt':
                msvcrt.locking(f.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(f.fileno(), fcntl.LOCK_UN)


def carpeta_respaldos():
    datos = os.environ.get('SIG_DATA_DIR','').strip()
    if datos:
        return Path(datos).expanduser().resolve() / 'respaldos'
    if os.environ.get('SIG_DB_PATH'):
        return db.ruta_bd().parent / 'respaldos'
    return Path(__file__).resolve().parent / 'respaldos'


def ultima_cita(ahora):
    """Último domingo 04:00 Chile (con cambios de hora de ZoneInfo)."""
    ahora = ahora.astimezone(CHILE)
    domingo = (ahora - timedelta(days=(ahora.weekday() + 1) % 7)).date()
    candidata = datetime.combine(domingo, time(4, 0), tzinfo=CHILE)
    if ahora < candidata:
        candidata -= timedelta(days=7)
    return candidata.date().isoformat()


def ejecutar_pendiente(ahora=None):
    ahora = ahora or ahora_chile()
    carpeta = carpeta_respaldos()
    carpeta.mkdir(parents=True, exist_ok=True)
    clave = ultima_cita(ahora)
    dbpath = str(db.ruta_bd())
    control = carpeta / '.control_respaldo_semanal.json'
    with _candado(carpeta / '.candado_respaldo_semanal'):
        try:
            estado = json.loads(control.read_text(encoding='utf-8'))
        except (OSError, ValueError):
            estado = {}
        if (estado.get('semana') == clave and estado.get('db') == dbpath
                and (carpeta / estado.get('archivo','')).is_file()):
            return 'YA_REALIZADO', carpeta / estado['archivo']
        destino, _ = respaldar(carpeta=carpeta, dias=60, reloj=ahora)
        nuevo = {'semana':clave,'db':dbpath,'archivo':destino.name,'fecha':ahora.isoformat()}
        temporal = control.with_suffix('.tmp')
        temporal.write_text(json.dumps(nuevo, ensure_ascii=False), encoding='utf-8')
        temporal.replace(control)
        return 'CREADO', destino


def bucle_respaldo(stop=None, intervalo_segundos=900):
    stop = stop or Event()
    while not stop.is_set():
        try:
            ejecutar_pendiente()
        except Exception as ex:
            _registrar_error(ex)
        stop.wait(intervalo_segundos)


def _registrar_error(ex):
    try:
        carpeta = carpeta_respaldos()
        carpeta.mkdir(parents=True, exist_ok=True)
        with (carpeta / 'historial_respaldos.log').open('a', encoding='utf-8') as f:
            f.write(f'{ahora_chile().isoformat()} ERROR AUTO {type(ex).__name__}: {ex}\n')
    except OSError:
        pass


def iniciar_supervision():
    Thread(target=bucle_respaldo, daemon=True, name='SIG-respaldo-semanal').start()


def registrar_tarea_windows():
    """Registra disparadores domingo 04:00 e inicio de sesión, mismo EXE.

    Si Windows impide registrarla, la comprobación al iniciar el SIG permanece.
    No almacena credenciales y no usa archivos BAT en la distribución.
    """
    if os.name != 'nt' or not getattr(sys, 'frozen', False):
        return False
    # Guardar la ruta real para el proceso independiente programado.
    exe = str(Path(sys.executable).resolve())
    ruta = str(db.ruta_bd())
    datos = str(carpeta_respaldos().parent)
    import base64
    def comillas_ps(s):
        return "'" + s.replace("'", "''") + "'"
    script = f'''$ErrorActionPreference = 'Stop'
$exe = {comillas_ps(exe)}
$ruta = {comillas_ps(ruta)}
$datos = {comillas_ps(datos)}
$argumentos = '--respaldo-pendiente --ruta-db "' + $ruta + '" --ruta-datos "' + $datos + '"'
$accion = New-ScheduledTaskAction -Execute $exe -Argument $argumentos
$dom = New-ScheduledTaskTrigger -Weekly -DaysOfWeek Sunday -At '04:00'
$logon = New-ScheduledTaskTrigger -AtLogOn -User $env:USERNAME
$opciones = New-ScheduledTaskSettingsSet -StartWhenAvailable -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Hours 1)
Register-ScheduledTask -TaskName 'SIG Minimarket E2 - Respaldo automatico' -Action $accion -Trigger @($dom,$logon) -Settings $opciones -Description 'Respaldo SQLite semanal y recuperacion despues de apagado; retencion 60 dias' -Force | Out-Null
# Evita la coexistencia con la tarea antigua de 30 dias instalada por SIG anterior.
Unregister-ScheduledTask -TaskName 'SIG Minimarket - Respaldo semanal' -Confirm:$false -ErrorAction SilentlyContinue
'''
    codificado = base64.b64encode(script.encode('utf-16le')).decode('ascii')
    try:
        p = subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-EncodedCommand',codificado],
                           capture_output=True, text=True, timeout=30, creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        if p.returncode:
            raise RuntimeError(p.stderr[-500:] or 'Windows rechazó la tarea programada.')
        return True
    except Exception as ex:
        _registrar_error(ex)
        return False
