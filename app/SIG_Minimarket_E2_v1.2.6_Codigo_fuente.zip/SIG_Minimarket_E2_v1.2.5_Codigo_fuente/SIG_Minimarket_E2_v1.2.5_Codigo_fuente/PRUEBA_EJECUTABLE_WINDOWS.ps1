# Prueba de humo del ejecutable Windows, en localhost y con SQLite temporal.
$ErrorActionPreference = 'Stop'
$base = Split-Path -Parent $MyInvocation.MyCommand.Path
$exe = Join-Path $base 'dist\SIG_Minimarket_E2_v1.2.4\SIG_Minimarket_E2_v1.2.4.exe'
if (-not (Test-Path -LiteralPath $exe)) { throw 'Falta el ejecutable construido.' }
$originalDB = [Environment]::GetEnvironmentVariable('SIG_DB_PATH', 'Process')
$originalData = [Environment]::GetEnvironmentVariable('SIG_DATA_DIR', 'Process')
$temporal = Join-Path $env:TEMP ('SIG_WINDOWS_SMOKE_' + [guid]::NewGuid().ToString('N'))
$puerto = Get-Random -Minimum 48000 -Maximum 62000
$proceso = $null
try {
    $env:SIG_DB_PATH = ''
    $env:SIG_DATA_DIR = $temporal
    $env:SIG_NO_TASK_SETUP = '1'
    $proceso = Start-Process -FilePath $exe -ArgumentList @('--sin-navegador', '--puerto', "$puerto") -PassThru -WindowStyle Hidden
    $baseUrl = "http://127.0.0.1:$puerto"
    $bien = $false
    for ($i = 0; $i -lt 25; $i++) {
        if ($proceso.HasExited) { throw "El ejecutable termino antes de iniciar HTTP (codigo $($proceso.ExitCode))." }
        try {
            $salud = Invoke-RestMethod -Uri "$baseUrl/salud" -TimeoutSec 2
            if ($salud.correcto -and $salud.tablas -eq 9 -and $salud.vistas -eq 5) {
                $bien = $true
                break
            }
        } catch {
            Start-Sleep -Seconds 1
        }
    }
    if (-not $bien) { throw 'El ejecutable no respondio correctamente en /salud.' }
    $inicio = Invoke-WebRequest -Uri "$baseUrl/" -UseBasicParsing -TimeoutSec 5
    $ventas = Invoke-WebRequest -Uri "$baseUrl/ventas" -UseBasicParsing -TimeoutSec 5
    $css = Invoke-WebRequest -Uri "$baseUrl/static/estilos.css" -UseBasicParsing -TimeoutSec 5
    $jsVentas = Invoke-WebRequest -Uri "$baseUrl/static/ventas.js" -UseBasicParsing -TimeoutSec 5
    if ($inicio.StatusCode -ne 200 -or $ventas.StatusCode -ne 200 -or $css.StatusCode -ne 200 -or $jsVentas.StatusCode -ne 200) {
        throw 'Fallo la carga de una plantilla HTML o recurso estatico.'
    }
    if ($ventas.Content -notmatch 'id="comenzar-venta"' -or $ventas.Content -notmatch 'id="venta-curso" hidden' -or $jsVentas.Content -notmatch 'function iniciarVenta') {
        throw 'No se encontro la nueva pantalla POS de inicio y escaneo.'
    }
    $rutaDB = Join-Path $temporal 'database\minimarket.db'
    if (-not (Test-Path -LiteralPath $rutaDB)) { throw 'Falta SQLite externa a la carpeta del EXE.' }
    Write-Host 'PRUEBA DEL EXE CORRECTA: /salud, Inicio, Ventas, CSS y SQLite externa.'
} finally {
    if ($proceso -and -not $proceso.HasExited) {
        Stop-Process -Id $proceso.Id -Force -ErrorAction SilentlyContinue
    }
    [Environment]::SetEnvironmentVariable('SIG_DB_PATH', $originalDB, 'Process')
    [Environment]::SetEnvironmentVariable('SIG_DATA_DIR', $originalData, 'Process')
    if (Test-Path -LiteralPath $temporal) { Remove-Item -LiteralPath $temporal -Recurse -Force -ErrorAction SilentlyContinue }
}
