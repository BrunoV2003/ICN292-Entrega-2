"""Arranque del SIG empaquetable: servidor local y SQLite duradera fuera del binario.

La versión 1.2.4 registra, cuando Windows lo permite, la tarea de respaldos.
La base inicial incluida (vacia, solo con la estructura del SIG) se copia unicamente
cuando no existe ninguna base en el almacen de datos. SIG_DB_PATH siempre tiene
prioridad y nunca se crea.
"""
import argparse
from contextlib import closing
import os
from pathlib import Path
import shutil
import sqlite3
import sys
import tempfile
from threading import Thread
import webbrowser

NOMBRE_DATOS = 'SIG_Minimarket_E2'


def recursos(relativo):
    base = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parent))
    return base / relativo


def directorio_datos():
    definido = os.environ.get('SIG_DATA_DIR', '').strip()
    if definido:
        return Path(definido).expanduser().resolve()
    if os.name == 'nt':
        parent = Path(os.environ.get('LOCALAPPDATA') or (Path.home() / 'AppData' / 'Local'))
    else:
        parent = Path(os.environ.get('XDG_DATA_HOME') or (Path.home() / '.local' / 'share'))
    return (parent / NOMBRE_DATOS).expanduser().resolve()


def verificar_base_archivo(archivo):
    """Solo lectura, no crea ni migra ni modifica una base."""
    if not archivo.is_file():
        raise FileNotFoundError(f'No se encuentra la base SQLite: {archivo}')
    with closing(sqlite3.connect(archivo.as_uri() + '?mode=ro', uri=True)) as con:
        if con.execute('PRAGMA quick_check').fetchone()[0] != 'ok':
            raise ValueError(f'La integridad de SQLite no es correcta: {archivo}')
        if con.execute('PRAGMA foreign_key_check').fetchall():
            raise ValueError(f'La base SQLite tiene claves foraneas no validas: {archivo}')


def copiar_base_inicial_sin_sobrescribir(origen, destino):
    """La primera ejecucion copia la base inicial vacia; nunca sobrescribe un archivo existente."""
    verificar_base_archivo(origen)
    destino.parent.mkdir(parents=True, exist_ok=True)
    temporal_path = None
    try:
        # Mantener la conexion SQLite cerrada ANTES de renombrar o borrar archivos:
        # Windows no permite eliminar SQLite ni temporales todavia abiertos.
        with tempfile.NamedTemporaryFile(prefix='.sig_base_', suffix='.tmp', dir=destino.parent,
                                         delete=False) as temporal:
            temporal_path = Path(temporal.name)
            with origen.open('rb') as entrada:
                shutil.copyfileobj(entrada, temporal)
            temporal.flush()
            os.fsync(temporal.fileno())

        verificar_base_archivo(temporal_path)
        try:
            # En NTFS y otros sistemas de archivos compatibles, el enlace es
            # atomico y falla si el destino ya existe (sin sobrescribirlo).
            os.link(temporal_path, destino)
            creada = True
        except FileExistsError:
            creada = False
        except OSError:
            # Alternativa sin sobrescritura para unidades sin hardlinks.
            try:
                with destino.open('xb') as salida, temporal_path.open('rb') as entrada:
                    shutil.copyfileobj(entrada, salida)
                    salida.flush()
                    os.fsync(salida.fileno())
                creada = True
            except FileExistsError:
                creada = False
            except BaseException:
                destino.unlink(missing_ok=True)
                raise
        return creada
    finally:
        # Este bloque solo se ejecuta despues de cerrar NamedTemporaryFile.
        if temporal_path is not None:
            temporal_path.unlink(missing_ok=True)


def preparar_base():
    # Tambien con SIG_DB_PATH propio, los respaldos deben quedar fuera del EXE.
    os.environ.setdefault('SIG_DATA_DIR', str(directorio_datos()))
    dato_explicito = os.environ.get('SIG_DB_PATH', '').strip()
    if dato_explicito:
        ruta = Path(dato_explicito).expanduser().resolve()
        verificar_base_archivo(ruta)
        print(f'Base de datos configurada: {ruta}', flush=True)
        return ruta

    raiz = directorio_datos()
    archivo = raiz / 'database' / 'minimarket.db'
    if not archivo.exists():
        origen = recursos('base_inicial/minimarket.db') if getattr(sys, 'frozen', False) else recursos('database/minimarket.db')
        if copiar_base_inicial_sin_sobrescribir(origen, archivo):
            print('Se creo una base de datos nueva y vacia.', flush=True)
    verificar_base_archivo(archivo)
    os.environ['SIG_DB_PATH'] = str(archivo)
    os.environ.setdefault('SIG_DATA_DIR', str(raiz))
    print(f'Base de datos: {archivo}', flush=True)
    return archivo


def servidor_local(puerto, navegador):
    import db
    db.migrar_caja()
    from respaldo_automatico import ejecutar_pendiente, iniciar_supervision, registrar_tarea_windows
    try:
        estado, ruta=ejecutar_pendiente()
        print(f'Respaldo semanal: {estado} ({ruta})', flush=True)
    except Exception as ex:
        print(f'AVISO: No se pudo hacer el respaldo semanal: {ex}', file=sys.stderr, flush=True)
    if not os.environ.get('SIG_NO_TASK_SETUP'):
        if os.name=='nt' and getattr(sys,'frozen',False):
            print('Programador de Windows: '+('configurado' if registrar_tarea_windows() else 'no disponible; respaldo al iniciar SIG activo'),flush=True)
    iniciar_supervision()
    from app import app
    from waitress import create_server
    # create_server falla inmediatamente si el puerto esta ocupado.
    server = create_server(app, host='127.0.0.1', port=puerto, threads=1)
    direccion = f'http://127.0.0.1:{puerto}'
    print(f'SIG Minimarket iniciado: {direccion}', flush=True)
    print('Para cerrar el servidor, cierre esta ventana o pulse Ctrl+C.', flush=True)
    if navegador:
        Thread(target=lambda: webbrowser.open(direccion), daemon=True).start()
    server.run()


def main(argv=None):
    parser = argparse.ArgumentParser(description='SIG Minimarket E2: modo local, sin Python externo')
    acciones = parser.add_mutually_exclusive_group()
    acciones.add_argument('--verificar', action='store_true', help='Validar SQLite sin escrituras')
    acciones.add_argument('--respaldar', action='store_true', help='Crear respaldo manual verificado')
    acciones.add_argument('--respaldo-pendiente', action='store_true', help='Ejecutar respaldo automático si quedó pendiente')
    acciones.add_argument('--probar-restauracion', nargs='?', const='', metavar='ARCHIVO',
                          help='Restaurar solo en copia temporal; opcion: ruta de respaldo')
    parser.add_argument('--ruta-db',default=None,help='Ruta efectiva SQLite para tarea Windows')
    parser.add_argument('--ruta-datos',default=None,help='Carpeta de datos externa para tarea Windows')
    parser.add_argument('--sin-navegador', action='store_true')
    parser.add_argument('--puerto', type=int, default=None)
    args = parser.parse_args(argv)
    try:
        if args.ruta_db:os.environ['SIG_DB_PATH']=args.ruta_db
        if args.ruta_datos:os.environ['SIG_DATA_DIR']=args.ruta_datos
        preparar_base()
        if args.respaldo_pendiente:
            from respaldo_automatico import ejecutar_pendiente
            estado, ruta=ejecutar_pendiente()
            print(f'Respaldo semanal: {estado}: {ruta}',flush=True)
            return 0
        if args.verificar:
            from scripts.verificar_integridad import main as verificar
            return verificar()
        if args.respaldar:
            from scripts.respaldar import main as respaldar
            return respaldar()
        if args.probar_restauracion is not None:
            from scripts.probar_restauracion import main as restaurar
            return restaurar([args.probar_restauracion] if args.probar_restauracion else [])
        puerto = args.puerto if args.puerto is not None else int(os.environ.get('SIG_PORT', '5000'))
        if not (1 <= puerto <= 65535):
            raise ValueError('El puerto debe estar entre 1 y 65535.')
        servidor_local(puerto, navegador=not args.sin_navegador)
        return 0
    except (OSError, ValueError, sqlite3.Error) as error:
        print(f'ERROR SIG: {error}', file=sys.stderr, flush=True)
        return 1
    except KeyboardInterrupt:
        print('Servidor detenido.', flush=True)
        return 0


if __name__ == '__main__':
    raise SystemExit(main())
