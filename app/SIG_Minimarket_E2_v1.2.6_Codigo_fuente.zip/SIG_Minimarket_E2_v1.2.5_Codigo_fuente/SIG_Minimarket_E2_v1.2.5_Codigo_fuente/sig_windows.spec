# -*- mode: python ; coding: utf-8 -*-
# Este archivo se ejecuta con PyInstaller en Windows 64 bits.
from pathlib import Path
from PyInstaller.utils.hooks import collect_data_files, collect_submodules

raiz = Path(SPECPATH)
contenido = [
    (str(raiz / 'templates'), 'templates'),
    (str(raiz / 'static'), 'static'),
    (str(raiz / 'database' / 'minimarket.db'), 'base_inicial'),
] + collect_data_files('tzdata')

analisis = Analysis(
    [str(raiz / 'sig_windows.py')],
    pathex=[str(raiz)],
    binaries=[],
    datas=contenido,
    hiddenimports=collect_submodules('tzdata'),
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=['pytest'],
    noarchive=False,
)
pyz = PYZ(analisis.pure)
exe = EXE(
    pyz, analisis.scripts, [],
    exclude_binaries=True,
    name='SIG_Minimarket_E2_v1.2.4',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=True,
    disable_windowed_traceback=False,
)
coll = COLLECT(
    exe, analisis.binaries, analisis.datas,
    strip=False,
    upx=False,
    name='SIG_Minimarket_E2_v1.2.4',
)
