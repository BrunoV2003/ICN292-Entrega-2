"""Pagos y arqueo local. La IA solo interpreta documentos; las cuentas se hacen aquí."""
import json
from datetime import date
from operaciones import ErrorOperacion, entero, texto
from reloj import hoy_chile, ahora_utc_sql
import db


def resumen_pagos(con, fecha):
    filas = con.execute('''SELECT p.medio, COALESCE(SUM(p.monto_clp),0) AS monto,
            COUNT(*) AS movimientos FROM sig_pago_venta p
            JOIN sig_folio_venta f ON f.id_venta=p.id_venta WHERE f.fecha_local=?
            GROUP BY p.medio''',(fecha,)).fetchall()
    medios={r['medio']: {'monto':int(r['monto']),'movimientos':r['movimientos']} for r in filas}
    sin=con.execute('''SELECT COUNT(*) FROM sig_folio_venta f
        WHERE f.fecha_local=? AND NOT EXISTS (SELECT 1 FROM sig_pago_venta p WHERE p.id_venta=f.id_venta)''',(fecha,)).fetchone()[0]
    total=con.execute('''SELECT COALESCE(SUM(d.cantidad*d.precio_unitario),0)
        FROM detalle_venta d JOIN sig_folio_venta f ON f.id_venta=d.id_venta
        WHERE f.fecha_local=?''',(fecha,)).fetchone()[0]
    return {'efectivo':medios.get('EFECTIVO',{}).get('monto',0),
            'transbank':medios.get('TRANSBANK',{}).get('monto',0),
            'sin_medio':sin,'total':int(total)}


def guardar_arqueo(datos, fecha=None):
    fecha=fecha or hoy_chile()
    fondo=entero(datos.get('fondo_inicial_clp'),'Fondo inicial')
    ingresos=entero(datos.get('ingresos_clp') or '0','Otros ingresos')
    retiros=entero(datos.get('retiros_clp') or '0','Retiros')
    contado=entero(datos.get('contado_clp'),'Efectivo contado')
    observacion=texto(datos,'observacion',500)
    with db.escritura() as con:
        actual=con.execute('SELECT estado FROM sig_jornada WHERE fecha_local=?',(fecha,)).fetchone()
        if actual and actual['estado']=='CERRADA':
            raise ErrorOperacion('No puedes editar el arqueo de una jornada cerrada.')
        pagos=resumen_pagos(con,fecha)
        esperado=fondo+ingresos+pagos['efectivo']-retiros
        if esperado<0:
            raise ErrorOperacion('Los retiros superan el efectivo disponible.')
        con.execute('''INSERT INTO sig_arqueo_caja(fecha_local,fondo_inicial_clp,ingresos_clp,retiros_clp,
               contado_clp,esperado_clp,diferencia_clp,observacion,actualizado_utc)
               VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(fecha_local) DO UPDATE SET
               fondo_inicial_clp=excluded.fondo_inicial_clp,ingresos_clp=excluded.ingresos_clp,
               retiros_clp=excluded.retiros_clp,contado_clp=excluded.contado_clp,
               esperado_clp=excluded.esperado_clp,diferencia_clp=excluded.diferencia_clp,
               observacion=excluded.observacion, actualizado_utc=excluded.actualizado_utc''',
               (fecha,fondo,ingresos,retiros,contado,esperado,contado-esperado,observacion,ahora_utc_sql()))
    return contado-esperado


def _monto(valor, campo, opcional=False):
    if valor is None or str(valor).strip()=='':
        if opcional:return None
        raise ErrorOperacion(f'No se pudo leer {campo} del reporte.')
    if isinstance(valor,bool) or not isinstance(valor,(int,str)):
        raise ErrorOperacion(f'El monto {campo} no es entero.')
    return entero(valor,campo,0,1000000000)


def validar_reporte(datos):
    if not isinstance(datos,dict):raise ErrorOperacion('El reporte interpretado no es válido.')
    fecha=(datos.get('fecha_reporte') or '').strip()
    if fecha:
        try: date.fromisoformat(fecha)
        except ValueError:raise ErrorOperacion('La fecha del reporte no es válida.')
    tipo=str(datos.get('nivel_detalle') or 'RESUMEN').upper()
    if tipo not in ('RESUMEN','DETALLE'):raise ErrorOperacion('Tipo de detalle desconocido.')
    total=_monto(datos.get('total_reporte_clp'),'total Transbank',opcional=True)
    operaciones=datos.get('operaciones') or []
    if not isinstance(operaciones,list) or len(operaciones)>100:
        raise ErrorOperacion('El reporte supera el límite de 100 operaciones. Usa el resumen.')
    normal=[]
    for item in operaciones:
        if not isinstance(item,dict):raise ErrorOperacion('Operación mal formada.')
        referencia=str(item.get('referencia') or '').strip()[:100]
        monto=_monto(item.get('monto_clp'),'operación')
        normal.append({'referencia':referencia,'monto_clp':monto})
    return {'fecha_reporte':fecha,'terminal':str(datos.get('terminal') or '')[:80],
            'periodo_inicio':str(datos.get('periodo_inicio') or '')[:40],
            'periodo_fin':str(datos.get('periodo_fin') or '')[:40],
            'nivel_detalle':tipo,'total_reporte_clp':total,'operaciones':normal}


def conciliar(datos,fecha=None,guardar=False,observacion=''):
    fecha=fecha or hoy_chile()
    datos=validar_reporte(datos)
    with (db.escritura() if guardar else db.lectura()) as con:
        pagos=resumen_pagos(con,fecha)
        sig=pagos['transbank']
        reporte=datos['total_reporte_clp']
        delta=(reporte-sig) if reporte is not None else None
        hallazgos=[]
        if not datos['fecha_reporte']:
            hallazgos.append('El reporte no indica una fecha verificable.')
        elif datos['fecha_reporte']!=fecha:
            hallazgos.append('La fecha del reporte no coincide con la jornada del SIG.')
        if datos['periodo_inicio'] or datos['periodo_fin']:
            hallazgos.append('Verifica que el período horario del terminal coincida con la jornada.')
        if reporte is None:
            hallazgos.append('No se pudo leer el total bruto de pagos del terminal.')
        if delta is not None and delta!=0:
            hallazgos.append(f'Diferencia: reporte menos SIG = {delta} CLP.')
        if pagos['sin_medio']:
            hallazgos.append(f'Hay {pagos["sin_medio"]} ventas sin método de pago registrado.')
        individuales='NO_VERIFICABLES'
        if datos['nivel_detalle']=='DETALLE':
            sig_ops=con.execute('''SELECT p.referencia, p.monto_clp
                FROM sig_pago_venta p JOIN sig_folio_venta f ON f.id_venta=p.id_venta
                WHERE f.fecha_local=? AND p.medio='TRANSBANK' ''',(fecha,)).fetchall()
            a=[(r['referencia'],int(r['monto_clp'])) for r in sig_ops]
            b=[(r['referencia'],r['monto_clp']) for r in datos['operaciones']]
            if a and len(a)==len(b) and all(ref for ref,_ in a+b) and len({r for r,_ in a})==len(a) and len({r for r,_ in b})==len(b):
                individuales='VERIFICADAS' if sorted(a)==sorted(b) else 'DIFERENCIAS'
                if individuales=='DIFERENCIAS':hallazgos.append('Las referencias y montos individuales no coinciden.')
            else:
                hallazgos.append('No hay referencias únicas comparables para verificar cada pago.')
        if datos['nivel_detalle']=='RESUMEN':
            hallazgos.append('Reporte resumido: solo permite comparar totales, no operaciones individuales.')
        fecha_coincide=datos['fecha_reporte']==fecha
        if reporte is None or not fecha_coincide or pagos['sin_medio']:
            estado='INFORMACION_INSUFICIENTE'
        elif delta != 0 or individuales=='DIFERENCIAS':
            estado='DIFERENCIA'
        elif individuales=='VERIFICADAS':
            estado='OPERACIONES_VERIFICADAS'
        else:
            estado='TOTALES_COINCIDEN'
        resultado={'estado':estado,'individuales':individuales,'total_sig_clp':sig,
                   'total_reporte_clp':reporte,'diferencia_clp':delta,'hallazgos':hallazgos,
                   'operaciones':datos['operaciones'],'fecha_reporte':datos['fecha_reporte'],
                   'nivel_detalle':datos['nivel_detalle']}
        if guardar:
            actual=con.execute('SELECT estado FROM sig_jornada WHERE fecha_local=?',(fecha,)).fetchone()
            if actual and actual['estado']=='CERRADA':
                raise ErrorOperacion('La jornada ya está cerrada: no se puede modificar la conciliación.')
            con.execute('''INSERT INTO sig_conciliacion_transbank(fecha_local,fecha_reporte,periodo_inicio,periodo_fin,
                terminal,nivel_detalle,total_reporte_clp,total_sig_clp,diferencia_clp,estado,
                operaciones_json,hallazgos_json,observacion,actualizado_utc)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(fecha_local) DO UPDATE SET
                fecha_reporte=excluded.fecha_reporte, periodo_inicio=excluded.periodo_inicio,
                periodo_fin=excluded.periodo_fin,terminal=excluded.terminal,
                nivel_detalle=excluded.nivel_detalle,total_reporte_clp=excluded.total_reporte_clp,
                total_sig_clp=excluded.total_sig_clp,diferencia_clp=excluded.diferencia_clp,
                estado=excluded.estado,operaciones_json=excluded.operaciones_json,
                hallazgos_json=excluded.hallazgos_json,observacion=excluded.observacion,
                actualizado_utc=excluded.actualizado_utc''',
                (fecha,datos['fecha_reporte'],datos['periodo_inicio'],datos['periodo_fin'],
                 datos['terminal'],datos['nivel_detalle'],reporte,sig,delta,estado,
                 json.dumps(datos['operaciones'],ensure_ascii=False),json.dumps(hallazgos,ensure_ascii=False),
                 observacion[:500],ahora_utc_sql()))
        return resultado


def validar_cierre(con,fecha,excepcion=''):
    pagos=resumen_pagos(con,fecha)
    arq=con.execute('SELECT * FROM sig_arqueo_caja WHERE fecha_local=?',(fecha,)).fetchone()
    conc=con.execute('SELECT * FROM sig_conciliacion_transbank WHERE fecha_local=?',(fecha,)).fetchone()
    faltas=[]
    if pagos['total'] and arq is None: faltas.append('no hay arqueo de efectivo')
    if pagos['sin_medio']: faltas.append('hay ventas sin medio de pago')
    if pagos['transbank'] and conc is None: faltas.append('no se ha adjuntado reporte Transbank')
    elif conc and (conc['estado'] not in ('TOTALES_COINCIDEN','OPERACIONES_VERIFICADAS') or conc['total_sig_clp']!=pagos['transbank']):
        faltas.append('Transbank tiene diferencias, datos insuficientes o ventas nuevas')
    if arq and arq['diferencia_clp']: faltas.append('el efectivo contado no coincide')
    if arq and arq['esperado_clp'] != arq['fondo_inicial_clp']+arq['ingresos_clp']+pagos['efectivo']-arq['retiros_clp']:
        faltas.append('se registraron ventas después del último arqueo')
    if faltas and len(excepcion.strip())<12:
        raise ErrorOperacion('Revisa caja antes de cerrar: '+', '.join(faltas)+'. Para cerrar con diferencia, registra motivo de al menos 12 caracteres.')
    return faltas
