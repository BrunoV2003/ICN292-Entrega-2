"""SIG Minimarket E2: interfaz local en español para el SQLite aprobado."""
from datetime import date
from pathlib import Path
import hmac
import logging
import json
import os
import secrets
import sqlite3
from threading import Lock

from flask import Flask, abort, flash, jsonify, redirect, render_template, request, session, url_for

import db
from reloj import hoy_chile, ahora_chile, fecha_hora_chile, folio
from operaciones import (ErrorOperacion, guardar_producto, guardar_proveedor,
    guardar_pedido, cancelar_pedido, guardar_entrada, guardar_venta,
    guardar_ajuste, guardar_conteo, cerrar_jornada, reabrir_jornada, jornada_actual, resumen_jornada)

ROOT=Path(__file__).resolve().parent
app=Flask(__name__)
# Clave por proceso. No existe autenticación de usuarios; sólo se escucha localhost.
app.secret_key=os.environ.get('SIG_SECRET_KEY') or secrets.token_hex(32)
app.config.update(MAX_CONTENT_LENGTH=9*1024*1024, SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Lax')
logging.basicConfig(level=logging.INFO, format='%(levelname)s %(message)s')
logger=logging.getLogger('sig_minimarket')
USADOS=set()
CANDADO=Lock()

REPORTES={
 'alertas': ('Alertas de reposición', '''SELECT nombre AS producto, codigo_interno, stock_actual, punto_reposicion, estado_alerta, unidades_para_reponer, metodo_calculo FROM v_alertas_reposicion ORDER BY unidades_para_reponer DESC'''),
 'ingresos': ('Ingresos diarios', '''SELECT fecha_chile(fecha_hora) AS fecha, COUNT(*) AS cantidad_ventas, SUM(total_venta_clp) AS ingresos_clp FROM v_resumen_venta WHERE (:desde='' OR fecha_chile(fecha_hora)>=:desde) AND (:hasta='' OR fecha_chile(fecha_hora)<=:hasta) GROUP BY fecha_chile(fecha_hora) ORDER BY fecha DESC'''),
 'unidades': ('Unidades vendidas por producto', '''SELECT p.nombre AS producto, p.codigo_interno, SUM(d.cantidad) AS unidades_vendidas, SUM(d.cantidad*d.precio_unitario) AS ingresos_clp FROM detalle_venta d JOIN venta v ON v.id_venta=d.id_venta JOIN producto p ON p.id_producto=d.id_producto WHERE (:desde='' OR fecha_chile(v.fecha_hora)>=:desde) AND (:hasta='' OR fecha_chile(v.fecha_hora)<=:hasta) GROUP BY p.id_producto ORDER BY unidades_vendidas DESC'''),
 'margen': ('Margen bruto estimado por día', '''SELECT fecha_chile(fecha_hora) AS fecha, SUM(total_venta_clp) AS ingresos_clp, ROUND(SUM(costo_mercaderia_clp),2) AS costo_mercaderia_clp, ROUND(SUM(margen_bruto_estimado_clp),2) AS margen_bruto_estimado_clp FROM v_resumen_venta WHERE (:desde='' OR fecha_chile(fecha_hora)>=:desde) AND (:hasta='' OR fecha_chile(fecha_hora)<=:hasta) GROUP BY fecha_chile(fecha_hora) ORDER BY fecha DESC'''),
 'mermas': ('Mermas registradas', '''SELECT a.fecha_hora, p.nombre AS producto, a.cantidad_delta, a.costo_unitario_cpp, a.motivo FROM ajuste_inventario a JOIN producto p ON p.id_producto=a.id_producto WHERE a.tipo_ajuste='MERMA' AND (:desde='' OR fecha_chile(a.fecha_hora)>=:desde) AND (:hasta='' OR fecha_chile(a.fecha_hora)<=:hasta) ORDER BY a.fecha_hora DESC'''),
 'conteos': ('Comparación de conteos físicos', '''SELECT c.fecha_hora, p.nombre AS producto, c.stock_sistema, c.cantidad_fisica, c.cantidad_fisica-c.stock_sistema AS diferencia, c.observacion FROM conteo_fisico c JOIN producto p ON p.id_producto=c.id_producto WHERE (:desde='' OR fecha_chile(c.fecha_hora)>=:desde) AND (:hasta='' OR fecha_chile(c.fecha_hora)<=:hasta) ORDER BY c.fecha_hora DESC'''),
 'movimientos': ('Historial de movimientos de inventario', '''SELECT m.fecha_hora, p.nombre AS producto, p.codigo_interno, m.tipo_movimiento, m.variacion_stock, m.id_origen FROM v_movimientos_inventario m JOIN producto p ON p.id_producto=m.id_producto WHERE (:desde='' OR fecha_chile(m.fecha_hora)>=:desde) AND (:hasta='' OR fecha_chile(m.fecha_hora)<=:hasta) ORDER BY m.fecha_hora DESC,m.id_origen DESC'''),
 'reposicion': ('Puntos de reposición', '''SELECT nombre AS producto, codigo_interno, stock_actual,stock_minimo,plazo_entrega_dias,unidades_vendidas_14_dias,demanda_diaria_estimada,punto_reposicion,metodo_calculo FROM v_puntos_reposicion ORDER BY nombre'''),
 'pedidos': ('Estado de pedidos', '''SELECT id_pedido, proveedor, fecha_pedido,fecha_entrega_estimada,estado_gestion,unidades_solicitadas,unidades_recibidas,unidades_pendientes,estado_recepcion FROM v_estado_pedidos ORDER BY id_pedido DESC'''),
 'pendientes': ('Detalle de pedidos pendientes', '''SELECT ped.id_pedido, pr.nombre AS proveedor, p.nombre AS producto, dp.cantidad_solicitada, COALESCE((SELECT SUM(e.cantidad) FROM entrada_stock e WHERE e.id_detalle_pedido=dp.id_detalle_pedido),0) AS unidades_recibidas, dp.cantidad_solicitada-COALESCE((SELECT SUM(e.cantidad) FROM entrada_stock e WHERE e.id_detalle_pedido=dp.id_detalle_pedido),0) AS unidades_pendientes FROM detalle_pedido dp JOIN pedido ped ON ped.id_pedido=dp.id_pedido JOIN proveedor pr ON pr.id_proveedor=ped.id_proveedor JOIN producto p ON p.id_producto=dp.id_producto WHERE ped.estado_gestion='EMITIDO' AND dp.cantidad_solicitada>COALESCE((SELECT SUM(e.cantidad) FROM entrada_stock e WHERE e.id_detalle_pedido=dp.id_detalle_pedido),0) ORDER BY ped.id_pedido DESC''')
}
CAMPOS={
'codigo_interno':'Código interno','codigo_barras':'Código de barras','nombre':'Nombre',
'precio_venta':'Precio de venta','stock_actual':'Existencias','stock_minimo':'Mínimo manual',
'costo_promedio':'Costo promedio ponderado','plazo_entrega_dias':'Plazo (días)',
'proveedor':'Proveedor','producto':'Producto','id_pedido':'N.º pedido','id_origen':'N.º movimiento',
'unidades_solicitadas':'Solicitadas','unidades_recibidas':'Recibidas','unidades_pendientes':'Pendientes',
'unidades_vendidas':'Unidades vendidas','unidades_vendidas_14_dias':'Vendidas en 14 días',
'unidades_para_reponer':'Unidades para salir de alerta','punto_reposicion':'Punto de reposición',
'metodo_calculo':'Método de cálculo','estado_alerta':'Estado de alerta','estado_recepcion':'Recepción',
'estado_gestion':'Gestión','fecha_hora':'Fecha y hora','fecha_pedido':'Fecha del pedido',
'fecha_entrega_estimada':'Entrega estimada','fecha':'Fecha','cantidad_ventas':'Cantidad de ventas',
'ingresos_clp':'Ingresos (CLP)','total_venta_clp':'Total venta (CLP)',
'costo_mercaderia_clp':'Costo de mercadería (CLP)',
'margen_bruto_estimado_clp':'Margen bruto estimado (CLP)',
'cantidad_delta':'Variación','costo_unitario_cpp':'CPP histórico',
'motivo':'Motivo','stock_sistema':'Stock del sistema','cantidad_fisica':'Cantidad física',
'diferencia':'Diferencia','observacion':'Observación','tipo_movimiento':'Movimiento',
'variacion_stock':'Variación de stock','demanda_diaria_estimada':'Demanda diaria estimada',
}
ESTADOS={'AUTOMATICO_14_DIAS':'Automático (14 días)','MANUAL_RESPALDO':'Mínimo manual',
         'BAJO_UMBRAL':'Bajo el umbral','EN_UMBRAL':'En el umbral',
         'PENDIENTE':'Pendiente','PARCIAL':'Parcial','RECIBIDO':'Recibido',
         'CANCELADO':'Cancelado','EMITIDO':'Emitido','SIN_DETALLE':'Sin detalle',
         'MERMA':'Merma','CORRECCION':'Corrección','ENTRADA':'Entrada','VENTA':'Venta',
         'CARGA_INICIAL':'Carga inicial','RECEPCION':'Recepción'}

def clp(valor, decimales=0):
    if valor is None: return '—'
    try:
        number=float(valor)
        s=f'{number:,.{decimales}f}'
        return '$'+s.replace(',','X').replace('.',',').replace('X','.')
    except (ValueError,TypeError,OverflowError):
        return '—'

def numero(valor,decimales=4):
    if valor is None: return '—'
    try:
        s=f'{float(valor):,.{decimales}f}'
        return s.replace(',','X').replace('.',',').replace('X','.')
    except (TypeError,ValueError): return '—'

app.jinja_env.filters['hora_chile']=fecha_hora_chile
app.jinja_env.filters['clp']=clp
app.jinja_env.filters['numero']=numero
app.jinja_env.filters['estado']=lambda x:ESTADOS.get(str(x),x) if x is not None else '—'
app.jinja_env.filters['cabecera']=lambda x:CAMPOS.get(x,str(x).replace('_',' ').capitalize())

def moneda_reporte(nombre):
    return nombre.endswith('_clp') or nombre in ('precio_venta',)
app.jinja_env.globals['moneda_reporte']=moneda_reporte

@app.context_processor
def variables_comunes():
    if '_csrf' not in session:
        session['_csrf']=secrets.token_urlsafe(32)
    return {'csrf_token':session['_csrf'],'bd_nombre':db.ruta_bd().name}

@app.before_request
def proteger_formularios():
    # Migración aditiva después de un respaldo verificado de la base original.
    db.migrar_caja()
    if request.method=='POST':
        obtenido=request.form.get('_csrf','')
        esperado=session.get('_csrf','')
        if not esperado or not hmac.compare_digest(obtenido,esperado):
            abort(400, description='El formulario perdió su validación. Recarga la página y vuelve a intentarlo.')

@app.errorhandler(400)
def error_400(error):
    return render_template('error.html', titulo='Solicitud incorrecta', mensaje=getattr(error,'description','Revisa los datos enviados.')),400

@app.errorhandler(404)
def error_404(error):
    return render_template('error.html', titulo='No se encontró la página', mensaje='Revisa la dirección o vuelve al inicio.'),404

@app.errorhandler(413)
def error_413(error):
    return render_template('error.html', titulo='Formulario demasiado grande', mensaje='Reduce el tamaño del formulario.'),413

def mensaje_sql(ex):
    mensaje=str(ex)
    if 'UNIQUE constraint failed' in mensaje: return 'El código o registro ingresado ya existe.'
    if 'FOREIGN KEY constraint failed' in mensaje: return 'El registro está relacionado con otros movimientos y no puede modificarse así.'
    if 'CHECK constraint failed' in mensaje: return 'Los datos no cumplen las restricciones de la base de datos.'
    if 'NOT NULL constraint failed' in mensaje: return 'Falta un dato obligatorio.'
    if 'locked' in mensaje.lower(): return 'La base está ocupada. Intenta nuevamente.'
    # Algunos triggers devuelven mensajes comprensibles.
    if any(p in mensaje.lower() for p in ('stock insuficiente','recepcion excede','ajuste excede','pedido cancelado','cpp','producto inactivo','no se cancela')):
        return mensaje
    return 'La base de datos rechazó la operación. No se guardaron cambios.'

@app.errorhandler(ErrorOperacion)
@app.errorhandler(sqlite3.IntegrityError)
@app.errorhandler(sqlite3.OperationalError)
def error_operacion(ex):
    if isinstance(ex,ErrorOperacion): mensaje=str(ex)
    else:
        logger.warning('SQLite rechazó una operación: %s',ex)
        mensaje=mensaje_sql(ex)
    flash(mensaje,'error')
    if request.method=='POST':
        destino=request.path
        if destino in ('/ventas/cierre/leer-transbank','/ventas/cierre/conciliar','/ventas/cierre/arqueo'):
            return redirect(url_for('venta_cierre'),303)
        if destino=='/consultas':
            return redirect(url_for('consultas_ia'),303)
        if destino.endswith('/cancelar'): destino=destino[:-len('/cancelar')]
        return redirect(destino,303)
    return render_template('error.html',titulo='No se pudo completar',mensaje=mensaje),400

@app.errorhandler(db.EsquemaIncompatible)
@app.errorhandler(FileNotFoundError)
def error_base(ex):
    logger.warning('Base no disponible: %s',ex)
    return render_template('error.html',titulo='Base de datos no disponible',mensaje=str(ex)),503

@app.route('/')
def inicio():
    hoy=hoy_chile()
    with db.lectura() as con:
        resumen=resumen_jornada(con,hoy)
        cifras={
          'productos':con.execute('SELECT COUNT(*) FROM producto WHERE activo=1').fetchone()[0],
          'alertas':con.execute('SELECT COUNT(*) FROM v_alertas_reposicion').fetchone()[0],
          'ventas':resumen['ventas'],
          'ingresos':resumen['total_clp'],
          'margen':con.execute('''SELECT COALESCE(SUM(rv.margen_bruto_estimado_clp),0)
                 FROM v_resumen_venta rv JOIN sig_folio_venta f ON f.id_venta=rv.id_venta
                 WHERE f.fecha_local=?''',(hoy,)).fetchone()[0],
          'pedidos':con.execute("SELECT COUNT(*) FROM v_estado_pedidos WHERE estado_recepcion IN ('PENDIENTE','PARCIAL')").fetchone()[0],
          'fecha':hoy,
        }
        jornada=jornada_actual(con,hoy)
        ultimo_cierre=con.execute("SELECT * FROM sig_jornada WHERE cerrado_utc IS NOT NULL ORDER BY cerrado_utc DESC LIMIT 1").fetchone()
        alertas=con.execute('SELECT * FROM v_alertas_reposicion ORDER BY unidades_para_reponer DESC LIMIT 7').fetchall()
        pedidos=con.execute("SELECT * FROM v_estado_pedidos WHERE estado_recepcion IN ('PENDIENTE','PARCIAL') ORDER BY id_pedido DESC LIMIT 6").fetchall()
    return render_template('inicio.html',cifras=cifras,alertas=alertas,pedidos=pedidos,
                           jornada=jornada,ultimo_cierre=ultimo_cierre,activo='inicio')

@app.route('/productos')
def productos():
    q=request.args.get('q','').strip()[:100]
    with db.lectura() as con:
        lista=con.execute('''SELECT p.*,pr.nombre AS proveedor,v.punto_reposicion, v.metodo_calculo,
                           alerta.estado_alerta
                    FROM producto p LEFT JOIN proveedor pr ON pr.id_proveedor=p.id_proveedor_principal
                    LEFT JOIN v_puntos_reposicion v ON v.id_producto=p.id_producto
                    LEFT JOIN v_alertas_reposicion alerta ON alerta.id_producto=p.id_producto
                    WHERE (?='' OR p.nombre LIKE ? OR p.codigo_interno LIKE ? OR p.codigo_barras LIKE ?)
                    ORDER BY p.nombre LIMIT 500''',(q,'%'+q+'%','%'+q+'%','%'+q+'%')).fetchall()
    return render_template('productos.html',productos=lista,q=q,activo='productos')

@app.route('/productos/nuevo',methods=['GET','POST'])
@app.route('/productos/<int:identificador>/editar',methods=['GET','POST'])
def formulario_producto(identificador=None):
    if request.method=='POST':
        pid=guardar_producto(request.form,identificador)
        with db.lectura() as con:
            codigo=con.execute('SELECT codigo_interno FROM producto WHERE id_producto=?',(pid,)).fetchone()['codigo_interno']
        flash(f'Producto guardado. Código interno: {codigo}. El stock se modifica mediante entradas o ajustes.','exito')
        return redirect(url_for('productos'),303)
    with db.lectura() as con:
        item=con.execute('SELECT * FROM producto WHERE id_producto=?',(identificador,)).fetchone() if identificador else None
        if identificador and item is None: abort(404)
        proveedores=con.execute('SELECT * FROM proveedor ORDER BY nombre').fetchall()
    return render_template('producto_form.html',item=item,proveedores=proveedores,activo='productos')

@app.route('/proveedores')
def proveedores():
    with db.lectura() as con:
        lista=con.execute('SELECT * FROM proveedor ORDER BY nombre').fetchall()
    return render_template('proveedores.html',proveedores=lista,activo='proveedores')

@app.route('/proveedores/nuevo',methods=['GET','POST'])
@app.route('/proveedores/<int:identificador>/editar',methods=['GET','POST'])
def formulario_proveedor(identificador=None):
    if request.method=='POST':
        guardar_proveedor(request.form,identificador)
        flash('Proveedor guardado correctamente.','exito')
        return redirect(url_for('proveedores'),303)
    with db.lectura() as con:
        item=con.execute('SELECT * FROM proveedor WHERE id_proveedor=?',(identificador,)).fetchone() if identificador else None
        if identificador and item is None: abort(404)
    return render_template('proveedor_form.html',item=item,activo='proveedores')

@app.route('/pedidos')
def pedidos():
    with db.lectura() as con:
        lista=con.execute('SELECT * FROM v_estado_pedidos ORDER BY id_pedido DESC LIMIT 500').fetchall()
    return render_template('pedidos.html',pedidos=lista,activo='pedidos')

@app.route('/pedidos/nuevo',methods=['GET','POST'])
def pedido_nuevo():
    if request.method=='POST':
        identificador=guardar_pedido(request.form)
        flash(f'Pedido N.º {identificador} registrado.','exito')
        return redirect(url_for('pedido_detalle',identificador=identificador),303)
    with db.lectura() as con:
        proveedores=con.execute('SELECT * FROM proveedor WHERE activo=1 ORDER BY nombre').fetchall()
        productos=con.execute('SELECT * FROM producto WHERE activo=1 ORDER BY nombre').fetchall()
        hoy=hoy_chile()
    return render_template('pedido_nuevo.html',proveedores=proveedores,productos=productos,hoy=hoy,activo='pedidos')

@app.route('/pedidos/<int:identificador>')
def pedido_detalle(identificador):
    with db.lectura() as con:
        pedido=con.execute('SELECT * FROM v_estado_pedidos WHERE id_pedido=?',(identificador,)).fetchone()
        if pedido is None: abort(404)
        lineas=con.execute('''SELECT dp.*,p.nombre,p.codigo_interno,COALESCE((SELECT SUM(e.cantidad) FROM entrada_stock e WHERE e.id_detalle_pedido=dp.id_detalle_pedido),0) AS recibida
                          FROM detalle_pedido dp JOIN producto p ON p.id_producto=dp.id_producto WHERE dp.id_pedido=? ORDER BY dp.id_detalle_pedido''',(identificador,)).fetchall()
    return render_template('pedido_detalle.html',pedido=pedido,lineas=lineas,activo='pedidos')

@app.route('/pedidos/<int:identificador>/cancelar',methods=['POST'])
def pedido_cancelar(identificador):
    cancelar_pedido(identificador)
    flash('Pedido cancelado.','exito')
    return redirect(url_for('pedido_detalle',identificador=identificador),303)

@app.route('/entradas/nueva',methods=['GET','POST'])
def entradas():
    if request.method=='POST':
        guardar_entrada(request.form)
        flash('Recepción o carga registrada. Stock y CPP actualizados por SQLite.','exito')
        return redirect(url_for('entradas'),303)
    with db.lectura() as con:
        productos=con.execute('SELECT * FROM producto ORDER BY nombre').fetchall()
        proveedores=con.execute('SELECT * FROM proveedor ORDER BY nombre').fetchall()
        pendientes=con.execute('''SELECT dp.id_detalle_pedido,dp.id_pedido, dp.id_producto, p.nombre AS producto,pr.nombre AS proveedor,
                         dp.cantidad_solicitada-COALESCE((SELECT SUM(e.cantidad) FROM entrada_stock e WHERE e.id_detalle_pedido=dp.id_detalle_pedido),0) AS restante
                         FROM detalle_pedido dp JOIN pedido ped ON ped.id_pedido=dp.id_pedido JOIN producto p ON p.id_producto=dp.id_producto JOIN proveedor pr ON pr.id_proveedor=ped.id_proveedor
                         WHERE ped.estado_gestion='EMITIDO' AND dp.cantidad_solicitada>COALESCE((SELECT SUM(e.cantidad) FROM entrada_stock e WHERE e.id_detalle_pedido=dp.id_detalle_pedido),0)
                         ORDER BY dp.id_detalle_pedido DESC''').fetchall()
        recientes=con.execute('''SELECT e.*,p.nombre AS producto, p.stock_actual AS stock_actual,
                               p.costo_promedio AS cpp_actual, pr.nombre AS proveedor
                               FROM entrada_stock e JOIN producto p ON p.id_producto=e.id_producto
                               LEFT JOIN proveedor pr ON pr.id_proveedor=e.id_proveedor
                               ORDER BY e.id_entrada DESC LIMIT 35''').fetchall()
    return render_template('entradas.html',productos=productos,proveedores=proveedores,pendientes=pendientes,recientes=recientes,
                           linea_preseleccionada=request.args.get('linea',''),
                           producto_preseleccionado=request.args.get('producto',''),activo='entradas')

@app.route('/api/productos/codigo')
def api_producto_codigo():
    codigo=request.args.get('codigo','').strip()[:80]
    if not codigo:
        return jsonify({'error':'Ingresa un código de barras.'}),400
    with db.lectura() as con:
        p=con.execute('SELECT id_producto,nombre,codigo_barras,precio_venta,stock_actual,activo FROM producto WHERE codigo_barras=?',(codigo,)).fetchone()
    if p is None:
        return jsonify({'error':'Código de barras no registrado.'}),404
    return jsonify(dict(p))

@app.route('/reposicion')
def reposicion():
    return render_template('reposicion.html',activo='entradas')

@app.route('/ventas',methods=['GET','POST'])
@app.route('/ventas/nueva',methods=['GET','POST'])
def ventas():
    if request.method=='POST':
        nonce=request.form.get('nonce','')
        if not nonce or len(nonce)>120:
            raise ErrorOperacion('Formulario de venta inválido. Vuelve a iniciar una venta.')
        with CANDADO:
            if nonce in USADOS:
                raise ErrorOperacion('Esta venta ya fue enviada. Revisa el historial antes de repetirla.')
            USADOS.add(nonce)
            if len(USADOS)>1500: USADOS.clear(); USADOS.add(nonce)
        if request.form.get('medio_pago') not in ('EFECTIVO','TRANSBANK','MIXTO'):
            raise ErrorOperacion('Selecciona el medio de pago antes de confirmar la venta.')
        identificador=guardar_venta(request.form)
        with db.lectura() as con:
            f=con.execute('SELECT folio FROM sig_folio_venta WHERE id_venta=?',(identificador,)).fetchone()['folio']
        flash(f'Venta {f} guardada.','exito')
        return redirect(url_for('venta_detalle',identificador=identificador),303)
    fecha=hoy_chile()
    with db.lectura() as con:
        productos=con.execute('''SELECT id_producto,codigo_barras,nombre,precio_venta,stock_actual
            FROM producto WHERE activo=1 ORDER BY nombre''').fetchall()
        sin_codigo=[dict(p) for p in productos if p['codigo_barras'] is None]
        recientes=con.execute('''SELECT rv.*,f.folio,f.fecha_local
                    FROM v_resumen_venta rv JOIN sig_folio_venta f ON f.id_venta=rv.id_venta
                    ORDER BY rv.id_venta DESC LIMIT 30''').fetchall()
        estado=jornada_actual(con,fecha)
        siguiente=con.execute('SELECT COALESCE(MAX(secuencia),0)+1 FROM sig_folio_venta WHERE fecha_local=?',(fecha,)).fetchone()[0]
    return render_template('ventas.html',recientes=recientes,sin_codigo=sin_codigo,
                           folio_provisional=folio(fecha,siguiente),fecha=fecha,
                           jornada=estado,nonce=secrets.token_urlsafe(20),activo='ventas')

@app.route('/ventas/<int:identificador>')
def venta_detalle(identificador):
    with db.lectura() as con:
        venta=con.execute('''SELECT rv.*,f.folio,f.fecha_local FROM v_resumen_venta rv
                           JOIN sig_folio_venta f ON f.id_venta=rv.id_venta WHERE rv.id_venta=?''',(identificador,)).fetchone()
        if venta is None: abort(404)
        pagos=con.execute('SELECT medio,monto_clp,referencia,tipo_tarjeta FROM sig_pago_venta WHERE id_venta=?',(identificador,)).fetchall()
        lineas=con.execute('''SELECT d.*,p.nombre,p.codigo_interno,p.stock_actual AS stock_actual
            FROM detalle_venta d JOIN producto p ON p.id_producto=d.id_producto WHERE d.id_venta=?''',(identificador,)).fetchall()
    return render_template('venta_detalle.html',venta=venta,lineas=lineas,pagos=pagos,activo='ventas')

@app.route('/ventas/cierre',methods=['GET','POST'])
def venta_cierre():
    if request.method=='POST':
        if request.form.get('confirmar')!='SI':
            raise ErrorOperacion('Debes confirmar el cierre del día.')
        _,nuevo=cerrar_jornada(validar_caja=True,excepcion=request.form.get('excepcion_cierre',''))
        flash('Día cerrado y resumen guardado.' if nuevo else 'El día ya estaba cerrado.','exito')
        return redirect(url_for('venta_cierre'),303)
    fecha=hoy_chile()
    with db.lectura() as con:
        resumen=resumen_jornada(con,fecha)
        estado=jornada_actual(con,fecha)
        folios=con.execute('SELECT folio,id_venta FROM sig_folio_venta WHERE fecha_local=? ORDER BY secuencia',(fecha,)).fetchall()
        eventos=con.execute('''SELECT * FROM sig_evento_jornada WHERE fecha_local=? ORDER BY id_evento DESC''',(fecha,)).fetchall()
        from caja import resumen_pagos
        pagos=resumen_pagos(con,fecha)
        arqueo=con.execute('SELECT * FROM sig_arqueo_caja WHERE fecha_local=?',(fecha,)).fetchone()
        conciliacion=con.execute('SELECT * FROM sig_conciliacion_transbank WHERE fecha_local=?',(fecha,)).fetchone()
    from gemini_sig import disponible
    return render_template('venta_cierre.html',fecha=fecha,resumen=resumen,jornada=estado,folios=folios,
                           eventos=eventos,pagos=pagos,arqueo=arqueo,conciliacion=conciliacion,
                           gemini_disponible=disponible(),activo='ventas')


@app.route('/ventas/cierre/arqueo',methods=['POST'])
def arqueo_caja():
    from caja import guardar_arqueo
    diferencia=guardar_arqueo(request.form)
    flash(f'Arqueo guardado. Diferencia: {clp(diferencia)}.','exito' if diferencia==0 else 'error')
    return redirect(url_for('venta_cierre'),303)

@app.route('/ventas/cierre/leer-transbank',methods=['POST'])
def leer_transbank():
    from gemini_sig import extraer_reporte
    from caja import conciliar
    archivo=request.files.get('reporte')
    if not archivo or not archivo.filename:
        raise ErrorOperacion('Adjunta una foto o PDF del reporte Transbank.')
    contenido=archivo.read(8*1024*1024+1)
    datos=extraer_reporte(contenido,archivo.mimetype)
    resultado=conciliar(datos)
    return render_template('transbank_revision.html',datos=datos,resultado=resultado,activo='ventas')

@app.route('/ventas/cierre/conciliar',methods=['POST'])
def conciliar_transbank():
    from caja import conciliar
    try:
        datos=json.loads(request.form.get('datos_json',''))
    except (ValueError,TypeError):
        raise ErrorOperacion('Formato del reporte incorrecto.')
    if 'total_reporte_clp' in request.form:
        valor=request.form.get('total_reporte_clp','').strip()
        if not valor.isdecimal():
            raise ErrorOperacion('El monto Transbank debe ser un entero en pesos chilenos.')
        datos['total_reporte_clp']=int(valor)
    if 'fecha_reporte' in request.form:
        datos['fecha_reporte']=request.form.get('fecha_reporte','').strip()
    resultado=conciliar(datos,guardar=True,observacion=request.form.get('observacion',''))
    flash('Conciliación guardada: '+resultado['estado'].replace('_',' ').lower()+'.','exito')
    return redirect(url_for('venta_cierre'),303)

@app.route('/consultas',methods=['GET','POST'])
def consultas_ia():
    resultado=None
    if request.method=='POST':
        from gemini_sig import preguntar
        resultado=preguntar(request.form.get('pregunta',''))
    from gemini_sig import disponible
    return render_template('consultas.html',resultado=resultado,gemini_disponible=disponible(),activo='consultas')

@app.route('/ventas/reabrir',methods=['POST'])
def venta_reabrir():
    pin=os.environ.get('SIG_ADMIN_PIN','')
    if len(pin)<6:
        raise ErrorOperacion('Para reabrir, configura primero SIG_ADMIN_PIN (mínimo 6 caracteres) en Windows.')
    if not hmac.compare_digest(request.form.get('pin',''),pin):
        raise ErrorOperacion('Código de autorización incorrecto.')
    reabrir_jornada(request.form.get('confirmacion',''))
    flash('Jornada reabierta. La reapertura quedó registrada en el historial.','exito')
    return redirect(url_for('ventas'),303)

@app.route('/inventario/ajustes',methods=['GET','POST'])
def ajustes():
    if request.method=='POST':
        guardar_ajuste(request.form)
        flash('Ajuste registrado. El stock fue modificado por el trigger de SQLite.','exito')
        return redirect(url_for('ajustes'),303)
    with db.lectura() as con:
        productos=con.execute('SELECT * FROM producto ORDER BY nombre').fetchall()
        recientes=con.execute('''SELECT a.*,p.nombre AS producto FROM ajuste_inventario a JOIN producto p ON p.id_producto=a.id_producto ORDER BY a.id_ajuste DESC LIMIT 50''').fetchall()
    return render_template('ajustes.html',productos=productos,recientes=recientes,activo='inventario')

@app.route('/inventario/conteos',methods=['GET','POST'])
def conteos():
    if request.method=='POST':
        guardar_conteo(request.form)
        flash('Conteo registrado. No se cambió el stock; las correcciones se hacen por separado.','exito')
        return redirect(url_for('conteos'),303)
    with db.lectura() as con:
        productos=con.execute('SELECT * FROM producto ORDER BY nombre').fetchall()
        recientes=con.execute('''SELECT c.*,p.nombre AS producto FROM conteo_fisico c JOIN producto p ON p.id_producto=c.id_producto ORDER BY c.id_conteo DESC LIMIT 50''').fetchall()
    return render_template('conteos.html',productos=productos,recientes=recientes,activo='inventario')

@app.route('/alertas')
def alertas():
    with db.lectura() as con:
        lista=con.execute('SELECT * FROM v_alertas_reposicion ORDER BY unidades_para_reponer DESC').fetchall()
        puntos=con.execute('SELECT * FROM v_puntos_reposicion ORDER BY nombre').fetchall()
    return render_template('alertas.html',alertas=lista,puntos=puntos,activo='alertas')

@app.route('/reportes')
def reportes():
    tipo=request.args.get('tipo','ingresos')
    if tipo not in REPORTES: abort(404)
    desde=request.args.get('desde','').strip()
    hasta=request.args.get('hasta','').strip()
    for fecha in (desde,hasta):
        if fecha:
            try:
                if date.fromisoformat(fecha).isoformat()!=fecha: raise ValueError
            except ValueError:
                return render_template('error.html',titulo='Fecha incorrecta',mensaje='Usa fechas válidas en el filtro.'),400
    if desde and hasta and desde>hasta:
        return render_template('error.html',titulo='Período incorrecto',mensaje='La fecha inicial debe ser anterior o igual a la final.'),400
    nombre,sql=REPORTES[tipo]
    with db.lectura() as con:
        cursor=con.execute(sql+' LIMIT 500',{'desde':desde,'hasta':hasta})
        columnas=[col[0] for col in cursor.description]
        filas=cursor.fetchall()
    return render_template('reportes.html',titulo=nombre,tipo=tipo,desde=desde,hasta=hasta,
                           reportes=REPORTES,columnas=columnas,filas=filas,activo='reportes')

@app.route('/salud')
def salud():
    with db.lectura() as con:
        d=db.diagnostico(con)
        return jsonify({'correcto':d['integridad']=='ok' and d['errores_fk']==0,
                        'tablas':d['tablas'],'vistas':d['vistas'],
                        'triggers':d['triggers'],'integridad':d['integridad'],
                        'errores_claves_foraneas':d['errores_fk']})

if __name__=='__main__':
    # Único equipo, sin acceso remoto ni modo de depuración.
    from waitress import serve
    serve(app,host='127.0.0.1',port=int(os.environ.get('SIG_PORT','5000')),threads=1)
