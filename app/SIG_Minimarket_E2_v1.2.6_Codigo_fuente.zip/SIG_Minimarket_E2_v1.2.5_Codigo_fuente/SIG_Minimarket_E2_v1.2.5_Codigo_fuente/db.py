"""Acceso a la base SQLite del SIG; no crea ni modifica su estructura."""
from contextlib import contextmanager
import os
from pathlib import Path
import sqlite3
from reloj import fecha_chile_sql

BASE = Path(__file__).resolve().parent
TABLAS = {'proveedor','producto','pedido','detalle_pedido','entrada_stock',
          'venta','detalle_venta','ajuste_inventario','conteo_fisico'}
VISTAS = {'v_puntos_reposicion','v_alertas_reposicion','v_estado_pedidos',
          'v_resumen_venta','v_movimientos_inventario'}
TABLAS_AUXILIARES = {'sig_folio_venta','sig_jornada','sig_evento_jornada'}
TABLAS_CAJA = {'sig_pago_venta','sig_arqueo_caja','sig_conciliacion_transbank'}
TRIGGERS_NECESARIOS = {'tr_entrada_actualiza_producto','tr_detalle_descuenta_stock',
                       'tr_ajuste_actualiza_stock','tr_detalle_validar',
                       'tr_entrada_validar_pedido','tr_conteo_validar','tr_ajuste_validar'}
COLUMNAS_NECESARIAS = {
 'producto': {'id_producto','codigo_interno','codigo_barras','nombre','precio_venta','stock_actual','costo_promedio','stock_minimo','id_proveedor_principal','activo'},
 'venta': {'id_venta','fecha_hora','observacion'},
 'detalle_venta': {'id_venta','id_producto','cantidad','precio_unitario','costo_unitario_cpp'},
 'proveedor': {'id_proveedor','nombre','plazo_entrega_dias','activo'},
 'pedido': {'id_pedido','id_proveedor','fecha_entrega_estimada','estado_gestion','observacion'},
 'detalle_pedido': {'id_detalle_pedido','id_pedido','id_producto','cantidad_solicitada','costo_unitario_estimado'},
 'entrada_stock': {'id_producto','id_proveedor','id_detalle_pedido','tipo_entrada','cantidad','costo_unitario','referencia_documento','observacion'},
 'ajuste_inventario': {'id_producto','tipo_ajuste','cantidad_delta','motivo','costo_unitario_cpp'},
 'conteo_fisico': {'id_producto','stock_sistema','cantidad_fisica','observacion'},
}

class EsquemaIncompatible(RuntimeError):
    pass

def ruta_bd():
    return Path(os.environ.get('SIG_DB_PATH', str(BASE / 'database' / 'minimarket.db'))).expanduser().resolve()

def conectar(escritura=False):
    ruta = ruta_bd()
    if not ruta.is_file():
        raise FileNotFoundError(f'No se encontró la base de datos: {ruta}.')
    # Abrir una BD inexistente JAMÁS debe crear un archivo vacío.
    uri = ruta.as_uri() + ('?mode=rw' if escritura else '?mode=ro')
    con = sqlite3.connect(uri, uri=True, timeout=10, isolation_level=None)
    con.row_factory = sqlite3.Row
    con.execute('PRAGMA foreign_keys=ON')
    con.execute('PRAGMA busy_timeout=10000')
    con.create_function('fecha_chile', 1, fecha_chile_sql, deterministic=True)
    if not escritura:
        con.execute('PRAGMA query_only=ON')
    try:
        verificar_esquema(con)
    except BaseException:
        con.close()
        raise
    return con

def verificar_esquema(con, exigir_auxiliares=True):
    obj = con.execute("SELECT name,type FROM sqlite_master WHERE type IN ('table','view','trigger') AND name NOT LIKE 'sqlite_%'").fetchall()
    tablas = {x['name'] for x in obj if x['type']=='table'}
    vistas = {x['name'] for x in obj if x['type']=='view'}
    triggers = {x['name'] for x in obj if x['type']=='trigger'}
    if not TABLAS <= tablas or not tablas <= TABLAS | TABLAS_AUXILIARES | TABLAS_CAJA or vistas != VISTAS or not TRIGGERS_NECESARIOS <= triggers:
        raise EsquemaIncompatible('La base no coincide con las nueve tablas, cinco vistas y triggers del SIG esperado. No se ha modificado nada.')
    if exigir_auxiliares and not TABLAS_AUXILIARES <= tablas:
        raise EsquemaIncompatible('Faltan metadatos de folios/jornadas. Ejecuta MIGRAR_BD.bat tras hacer respaldo.')
    for nombre, cols in COLUMNAS_NECESARIAS.items():
        existentes = {x['name'] for x in con.execute(f'PRAGMA table_info("{nombre}")')}
        if not cols <= existentes:
            raise EsquemaIncompatible(f'La tabla {nombre} no tiene las columnas esperadas. No se ha modificado nada.')

@contextmanager
def lectura():
    con=conectar(False)
    try:
        yield con
    finally:
        con.close()

@contextmanager
def escritura():
    con=conectar(True)
    try:
        con.execute('BEGIN IMMEDIATE')
        yield con
        con.commit()
    except BaseException:
        con.rollback()
        raise
    finally:
        con.close()

def diagnostico(con):
    return {
        'tablas': len(TABLAS), 'vistas': len(VISTAS),
        'triggers': con.execute("SELECT count(*) FROM sqlite_master WHERE type='trigger'").fetchone()[0],
        'integridad': con.execute('PRAGMA quick_check').fetchone()[0],
        'errores_fk': len(con.execute('PRAGMA foreign_key_check').fetchall()),
        'ruta': str(ruta_bd()),
    }


def migrar_caja():
    """Agrega solo tablas auxiliares, con copia SQLite verificada previa.

    No ejecuta schema.sql ni seed.sql, y nunca sobrescribe una BD del negocio.
    """
    ruta = ruta_bd()
    with lectura() as con:
        actuales = {r['name'] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    if TABLAS_CAJA <= actuales:
        return False
    # Se exige copia verificable fuera del fichero de datos, ANTES de cualquier DDL.
    import tempfile
    from contextlib import closing
    from datetime import datetime, timezone
    import uuid
    raiz = Path(os.environ.get('SIG_DATA_DIR') or ruta.parent)
    carpeta = raiz / 'respaldos' / 'pre_migracion'
    carpeta.mkdir(parents=True, exist_ok=True)
    destino = carpeta / ('antes_caja_' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S') + '_' + uuid.uuid4().hex[:8] + '.db')
    tmp = destino.with_suffix('.tmp')
    try:
        with lectura() as origen, closing(sqlite3.connect(tmp)) as copia:
            origen.backup(copia)
            copia.execute('PRAGMA foreign_keys=ON')
            if copia.execute('PRAGMA quick_check').fetchone()[0] != 'ok' or copia.execute('PRAGMA foreign_key_check').fetchall():
                raise RuntimeError('Falló la verificación del respaldo previo a migración')
        tmp.replace(destino)
        with escritura() as con:
            con.execute("""CREATE TABLE IF NOT EXISTS sig_pago_venta(
                id_pago INTEGER PRIMARY KEY,
                id_venta INTEGER NOT NULL REFERENCES venta(id_venta) ON DELETE RESTRICT,
                medio TEXT NOT NULL CHECK(medio IN ('EFECTIVO','TRANSBANK')),
                monto_clp INTEGER NOT NULL CHECK(monto_clp>=0),
                referencia TEXT,
                tipo_tarjeta TEXT,
                confirmado INTEGER NOT NULL DEFAULT 0 CHECK(confirmado IN (0,1)),
                registrado_utc TEXT NOT NULL,
                UNIQUE(id_venta,medio)
            )""")
            con.execute('CREATE INDEX IF NOT EXISTS idx_sig_pago_medio ON sig_pago_venta(medio,id_venta)')
            con.execute("""CREATE TABLE IF NOT EXISTS sig_arqueo_caja(
                fecha_local TEXT PRIMARY KEY,
                fondo_inicial_clp INTEGER NOT NULL CHECK(fondo_inicial_clp>=0),
                ingresos_clp INTEGER NOT NULL DEFAULT 0 CHECK(ingresos_clp>=0),
                retiros_clp INTEGER NOT NULL DEFAULT 0 CHECK(retiros_clp>=0),
                contado_clp INTEGER NOT NULL CHECK(contado_clp>=0),
                esperado_clp INTEGER NOT NULL CHECK(esperado_clp>=0),
                diferencia_clp INTEGER NOT NULL,
                observacion TEXT,
                excepcion_cierre TEXT,
                actualizado_utc TEXT NOT NULL
            )""")
            con.execute("""CREATE TABLE IF NOT EXISTS sig_conciliacion_transbank(
                fecha_local TEXT PRIMARY KEY,
                fecha_reporte TEXT,
                periodo_inicio TEXT,
                periodo_fin TEXT,
                terminal TEXT,
                nivel_detalle TEXT NOT NULL CHECK(nivel_detalle IN ('DETALLE','RESUMEN')),
                total_reporte_clp INTEGER,
                total_sig_clp INTEGER NOT NULL,
                diferencia_clp INTEGER,
                estado TEXT NOT NULL,
                operaciones_json TEXT NOT NULL DEFAULT '[]',
                hallazgos_json TEXT NOT NULL DEFAULT '[]',
                observacion TEXT,
                actualizado_utc TEXT NOT NULL
            )""")
    except BaseException:
        tmp.unlink(missing_ok=True)
        raise
    return True
